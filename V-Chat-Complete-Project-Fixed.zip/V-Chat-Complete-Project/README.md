# V-CHAT – Real-Time Multi-User Messaging Application

V-CHAT is a high-performance, real-time messaging application with Firebase Backend integration, built with React 19, TypeScript, Vite, Tailwind CSS v4, and Cloud Firestore.

## Features
- **User Authentication**: Email & password registration with unique username check, duplicate validation, profile photo upload, and session persistence.
- **Find Users & Contacts**: Real-time registered users directory with live search by username or full name and one-click direct chat initiation.
- **Real-Time Direct Messaging**: Instant bidirectional messaging powered by Cloud Firestore `onSnapshot` streaming with message history, timestamps, reply preview, and double read receipts (`done_all`).
- **Emoji Picker**: Multi-emoji selection popover with categories, live insertion into the input field, and large emoji rendering.
- **Photo & Video Sharing**: Gallery multi-selection, live camera capture with switchable front/back cameras, client-side image compression, captions, upload progress tracking, and full-screen lightbox image viewer with download.
- **Voice Notes & Audio**: In-browser audio recording via `MediaRecorder`, animated waveform visualization, timer duration counter, and inline audio playback.
- **Document & File Sharing**: Sharing of PDF, DOC, XLS, TXT, and ZIP documents with file size badges and download links.
- **Location & Contact Sharing**: Geolocation GPS sharing with direct Google Maps link and contact card sharing.
- **Group Chat**: Group creation with multi-member selector, group messages streaming, and admin controls.
- **Voice & Video Calls**: Interactive WebRTC calling overlay with ringing states, duration counter, mic mute, and camera toggle.
- **Security & Privacy**: ABAC and Master Gate security rules for Cloud Firestore and Firebase Storage.

---

## Getting Started

### 1. Prerequisites
- Node.js 18+ or 20+
- npm or bun

### 2. Installation
```bash
npm install
```

### 3. Firebase Configuration
The project is configured via `firebase-applet-config.json`. Ensure your Firebase project has:
1. **Firebase Authentication** enabled (Email/Password and Google providers).
2. **Cloud Firestore** database created (e.g. database ID `(default)` or custom `vchat-db`).
3. **Firebase Storage** bucket initialized.

Example `firebase-applet-config.json`:
```json
{
  "projectId": "your-firebase-project-id",
  "appId": "your-firebase-web-app-id",
  "apiKey": "your-firebase-api-key",
  "authDomain": "your-firebase-project-id.firebaseapp.com",
  "firestoreDatabaseId": "vchat-db",
  "storageBucket": "your-firebase-project-id.firebasestorage.app",
  "messagingSenderId": "your-sender-id"
}
```

#### Important: Firestore database ID
The included `firebase-applet-config.json` currently specifies `firestoreDatabaseId: "vchat-db"`.
Create a Firestore database with the exact ID `vchat-db` in the Firebase project. If you created only the default database, change that value to `(default)` before running the app.

New registrations write private account details to `users/{uid}` and safe directory details to `publicUsers/{uid}`. Existing users should log in once after deploying the updated rules so their public directory profile is synchronized.

## 4. Deploying Firestore & Storage Rules
Deploy the provided security rules to your Firebase project:
```bash
firebase deploy --only firestore:rules,storage:rules
```

### 5. Running the Application
```bash
npm run dev
```
Open your browser at `http://localhost:3000`.

---

## Architecture & Code Structure
```
├── firebase-applet-config.json  # Firebase configuration
├── firebase-blueprint.json      # Firestore intermediate schema definition
├── firestore.rules              # Hardened Attribute-Based Access Control rules
├── storage.rules                # Storage security rules
├── src/
│   ├── firebase/
│   │   ├── config.ts            # Firebase app, auth, db, and storage initialization
│   │   ├── error-handler.ts     # Standardized Firestore error diagnostic handler
│   │   ├── authService.ts       # Registration, login, password reset, and profiles
│   │   ├── chatService.ts       # Direct messaging, listeners, users directory, and reactions
│   │   ├── storageService.ts    # Media uploads, image compression, and thumbnails
│   │   ├── groupService.ts      # Group creation and group messaging
│   │   ├── callService.ts       # Voice and video call signaling and logging
│   │   └── reportService.ts     # Content moderation and user reporting
│   ├── components/
│   │   ├── Header.tsx               # Top navigation, logo, and actions
│   │   ├── PeerStatusBar.tsx        # Active chat peer status and call triggers
│   │   ├── MessageItem.tsx          # Chat bubble rendering all message types
│   │   ├── ComposerBar.tsx          # Always visible send button, mic, and emoji picker
│   │   ├── AttachmentDrawer.tsx     # 6-item media and content sharing drawer
│   │   ├── MediaPreviewModal.tsx    # Gallery photo and video preview with captions
│   │   ├── CameraCaptureModal.tsx   # Live device camera capture modal
│   │   ├── ImageViewerModal.tsx     # Full-screen photo lightbox with download
│   │   ├── CallModal.tsx            # Audio/video calling screen
│   │   ├── AuthModal.tsx            # Real registration and login dialog
│   │   ├── ConversationsDrawer.tsx  # Chats, Registered Users directory, and Groups
│   │   ├── GroupCreateModal.tsx     # Group creation modal
│   │   ├── ProfileModal.tsx         # User profile and avatar editor
│   │   ├── PrivacyModal.tsx         # Privacy settings
│   │   └── ReportModal.tsx          # Safety report modal
│   ├── types/
│   │   └── index.ts                 # TypeScript domain entities
│   ├── App.tsx                      # Root application controller
│   ├── main.tsx                     # React root mount
│   └── index.css                    # Tailwind CSS v4 styling & theme tokens
```


## Fixes included in this handoff
- The message composer now waits for the send operation and keeps the typed text if sending fails.
- Sending without an open conversation now opens the registered-users drawer instead of trying to use stale React state.
- The app no longer silently opens the first registered user on login.
- Direct-chat creation errors are surfaced instead of returning a fake/minimal room.
- Registered-user discovery uses a `publicUsers` collection so directory listings do not expose private email/phone fields.
- Media upload failures are reported as failures; the app no longer substitutes a local Data URL that would not be available to the other device.
- Firestore and Storage rules were tightened around private profiles and chat participants.

These changes are source-code repairs. A live Firebase deployment and two-device end-to-end test are still required; this package has not been verified against the user's live Firebase project from this environment.
