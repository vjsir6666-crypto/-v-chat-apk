export type MessageType =
  | 'text'
  | 'image'
  | 'video'
  | 'document'
  | 'audio'
  | 'voice'
  | 'location'
  | 'contact';

export type MessageStatus = 'sending' | 'sent' | 'delivered' | 'read' | 'failed';

export interface LocationData {
  latitude: number;
  longitude: number;
  address?: string;
  name?: string;
}

export interface ContactData {
  name: string;
  phoneNumber: string;
  email?: string;
}

export interface MessageReactionMap {
  [emoji: string]: string[]; // emoji -> array of userIds
}

export interface ReplyPreview {
  messageId: string;
  senderId: string;
  senderName: string;
  messageText: string;
  messageType: MessageType;
}

export interface VChatMessage {
  messageId: string;
  chatId: string;
  senderId: string;
  receiverId?: string;
  messageText: string;
  messageType: MessageType;
  mediaUrl?: string;
  thumbnailUrl?: string;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  duration?: number;
  locationData?: LocationData;
  contactData?: ContactData;
  sentAt: string;
  deliveredAt?: string;
  readAt?: string;
  status: MessageStatus;
  replyTo?: ReplyPreview;
  forwarded?: boolean;
  reactions?: MessageReactionMap;
  deletedFor?: string[];
  deletedForEveryone?: boolean;
  starredBy?: string[];
}

export interface VChatUser {
  uid: string;
  fullName: string;
  username: string;
  email: string;
  phoneNumber?: string;
  countryCode?: string;
  profilePhotoUrl?: string;
  bio?: string;
  about?: string;
  createdAt: string;
  updatedAt?: string;
  lastSeen?: string;
  isOnline?: boolean;
  isVerified?: boolean;
  accountStatus?: 'active' | 'suspended' | 'deleted';
  fcmTokens?: string;
}

export interface ChatParticipantDetails {
  uid: string;
  fullName: string;
  username: string;
  profilePhotoUrl?: string;
  isOnline?: boolean;
  lastSeen?: string;
}

export interface VChatRoom {
  chatId: string;
  participants: string[];
  participantDetails?: { [uid: string]: ChatParticipantDetails };
  lastMessage?: string;
  lastMessageType?: MessageType;
  lastMessageTime?: string;
  lastMessageSenderId?: string;
  unreadCounts?: { [uid: string]: number };
  typingStatus?: { [uid: string]: boolean };
  createdAt: string;
  updatedAt?: string;
}

export interface VChatGroup {
  groupId: string;
  groupName: string;
  groupPhoto?: string;
  description?: string;
  createdBy: string;
  admins: string[];
  members: string[];
  groupType: 'public' | 'private';
  inviteLink?: string;
  lastMessage?: string;
  lastMessageType?: MessageType;
  lastMessageTime?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface VChatGroupMessage {
  messageId: string;
  groupId: string;
  senderId: string;
  senderName: string;
  senderPhoto?: string;
  messageText: string;
  messageType: MessageType;
  mediaUrl?: string;
  fileName?: string;
  fileSize?: number;
  duration?: number;
  locationData?: LocationData;
  contactData?: ContactData;
  sentAt: string;
  replyTo?: ReplyPreview;
  reactions?: MessageReactionMap;
  deletedFor?: string[];
  deletedForEveryone?: boolean;
}

export interface VChatCall {
  callId: string;
  callerId: string;
  callerName: string;
  callerPhoto?: string;
  receiverId: string;
  receiverName: string;
  receiverPhoto?: string;
  callType: 'voice' | 'video';
  status: 'ringing' | 'accepted' | 'declined' | 'ended' | 'missed';
  createdAt: string;
  durationSeconds?: number;
}

export interface VChatNotification {
  notificationId: string;
  receiverId: string;
  senderId: string;
  notificationType: 'message' | 'group_message' | 'call' | 'invitation' | 'alert';
  title: string;
  body: string;
  relatedId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface VChatReport {
  reportId: string;
  reporterId: string;
  targetType: 'user' | 'message' | 'group';
  targetId: string;
  reason: string;
  details?: string;
  createdAt: string;
}

export interface UserPrivacySettings {
  lastSeenVisibility: 'everyone' | 'contacts' | 'nobody';
  onlineVisibility: 'everyone' | 'contacts' | 'nobody';
  profilePhotoVisibility: 'everyone' | 'contacts' | 'nobody';
  readReceipts: boolean;
  blockedUsers: string[];
}
