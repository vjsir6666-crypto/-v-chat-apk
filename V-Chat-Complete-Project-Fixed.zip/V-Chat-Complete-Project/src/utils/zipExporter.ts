import JSZip from 'jszip';
import { PROJECT_SOURCE_FILES } from './projectFilesData';

/**
 * Generates and triggers instant browser download of V-Chat-Complete-Project.zip
 * directly from browser memory. Never requires external network calls or auth cookies.
 */
export async function downloadProjectZipLocally(): Promise<void> {
  const zip = new JSZip();
  const root = zip.folder('V-Chat-Complete-Project') || zip;

  for (const [filePath, content] of Object.entries(PROJECT_SOURCE_FILES)) {
    root.file(filePath, content);
  }

  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = 'V-Chat-Complete-Project.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  setTimeout(() => {
    URL.revokeObjectURL(blobUrl);
  }, 10000);
}
