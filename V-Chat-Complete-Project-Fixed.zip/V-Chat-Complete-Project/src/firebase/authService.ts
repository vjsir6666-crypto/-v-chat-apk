import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc,
  setDoc,
  getDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import { auth, db } from './config';
import { handleFirestoreError, OperationType } from './error-handler';
import { VChatUser } from '../types';

export interface RegisterPayload {
  fullName: string;
  username: string;
  email: string;
  phoneNumber?: string;
  countryCode?: string;
  password: string;
  bio?: string;
  profilePhotoUrl?: string;
}

export async function checkUsernameAvailable(username: string): Promise<boolean> {
  const clean = username.trim().toLowerCase();
  if (!clean || clean.length < 2) return false;
  try {
    const q = query(collection(db, 'publicUsers'), where('username', '==', clean));
    const snapshot = await getDocs(q);
    return snapshot.empty;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
    return false;
  }
}

export async function registerUser(payload: RegisterPayload): Promise<VChatUser> {
  const cleanUsername = payload.username.trim().toLowerCase();
  const cleanEmail = payload.email.trim().toLowerCase();

  // 1. Verify username availability
  const isAvailable = await checkUsernameAvailable(cleanUsername);
  if (!isAvailable) {
    throw new Error(`Username @${cleanUsername} is already taken. Please choose another.`);
  }

  // 2. Create Firebase Auth user
  const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, payload.password);
  const fbUser = userCredential.user;

  // 3. Update auth display name
  const photoUrl =
    payload.profilePhotoUrl ||
    `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(cleanUsername)}`;

  await updateProfile(fbUser, {
    displayName: payload.fullName,
    photoURL: photoUrl,
  });

  // 4. Create Firestore user document
  const vChatUser: VChatUser = {
    uid: fbUser.uid,
    fullName: payload.fullName.trim(),
    username: cleanUsername,
    email: cleanEmail,
    phoneNumber: payload.phoneNumber ? `${payload.countryCode || '+1'}${payload.phoneNumber}` : '',
    countryCode: payload.countryCode || '+1',
    profilePhotoUrl: photoUrl,
    bio: payload.bio || 'Available on V-CHAT',
    about: 'Hey there! I am using V-CHAT.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lastSeen: new Date().toISOString(),
    isOnline: true,
    isVerified: true,
    accountStatus: 'active',
  };

  const userDocRef = doc(db, 'users', fbUser.uid);
  try {
    await setDoc(userDocRef, vChatUser);
    await setDoc(doc(db, 'publicUsers', fbUser.uid), {
      uid: fbUser.uid,
      fullName: vChatUser.fullName,
      username: vChatUser.username,
      profilePhotoUrl: vChatUser.profilePhotoUrl,
      bio: vChatUser.bio,
      createdAt: vChatUser.createdAt,
      lastSeen: vChatUser.lastSeen,
      isOnline: true,
      accountStatus: 'active',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `users/${fbUser.uid}`);
  }

  return vChatUser;
}

export async function loginWithEmail(email: string, pass: string): Promise<VChatUser> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
  const fbUser = cred.user;

  // Update presence
  const userDocRef = doc(db, 'users', fbUser.uid);
  try {
    const userSnap = await getDoc(userDocRef);
    if (userSnap.exists()) {
      const lastSeen = new Date().toISOString();
      await updateDoc(userDocRef, { isOnline: true, lastSeen });
      const profile = userSnap.data() as VChatUser;
      await setDoc(doc(db, 'publicUsers', fbUser.uid), {
        uid: fbUser.uid, fullName: profile.fullName, username: profile.username,
        profilePhotoUrl: profile.profilePhotoUrl || '', bio: profile.bio || '',
        createdAt: profile.createdAt, lastSeen, isOnline: true, accountStatus: profile.accountStatus || 'active',
      }, { merge: true });
      return profile;
    } else {
      // First time login profile bootstrap
      const newUser: VChatUser = {
        uid: fbUser.uid,
        fullName: fbUser.displayName || 'V-Chat User',
        username: (fbUser.email?.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_]/g, ''),
        email: fbUser.email || '',
        profilePhotoUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
        createdAt: new Date().toISOString(),
        lastSeen: new Date().toISOString(),
        isOnline: true,
        isVerified: true,
        accountStatus: 'active',
      };
      await setDoc(userDocRef, newUser);
      await setDoc(doc(db, 'publicUsers', fbUser.uid), {
        uid: newUser.uid, fullName: newUser.fullName, username: newUser.username,
        profilePhotoUrl: newUser.profilePhotoUrl || '', bio: newUser.bio || '',
        createdAt: newUser.createdAt, lastSeen: newUser.lastSeen, isOnline: true, accountStatus: 'active',
      });
      return newUser;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${fbUser.uid}`);
    throw error;
  }
}

export async function loginWithGoogle(): Promise<VChatUser> {
  const provider = new GoogleAuthProvider();
  const cred = await signInWithPopup(auth, provider);
  const fbUser = cred.user;

  const userDocRef = doc(db, 'users', fbUser.uid);
  try {
    const userSnap = await getDoc(userDocRef);
    if (userSnap.exists()) {
      const lastSeen = new Date().toISOString();
      await updateDoc(userDocRef, { isOnline: true, lastSeen });
      const profile = userSnap.data() as VChatUser;
      await setDoc(doc(db, 'publicUsers', fbUser.uid), {
        uid: fbUser.uid, fullName: profile.fullName, username: profile.username,
        profilePhotoUrl: profile.profilePhotoUrl || '', bio: profile.bio || '',
        createdAt: profile.createdAt, lastSeen, isOnline: true, accountStatus: profile.accountStatus || 'active',
      }, { merge: true });
      return profile;
    } else {
      const newUser: VChatUser = {
        uid: fbUser.uid,
        fullName: fbUser.displayName || 'Google User',
        username: (fbUser.email?.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_]/g, ''),
        email: fbUser.email || '',
        profilePhotoUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
        createdAt: new Date().toISOString(),
        lastSeen: new Date().toISOString(),
        isOnline: true,
        isVerified: true,
        accountStatus: 'active',
      };
      await setDoc(userDocRef, newUser);
      await setDoc(doc(db, 'publicUsers', fbUser.uid), {
        uid: newUser.uid, fullName: newUser.fullName, username: newUser.username,
        profilePhotoUrl: newUser.profilePhotoUrl || '', bio: newUser.bio || '',
        createdAt: newUser.createdAt, lastSeen: newUser.lastSeen, isOnline: true, accountStatus: 'active',
      });
      return newUser;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${fbUser.uid}`);
    throw error;
  }
}

export async function resetUserPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

export async function getUserProfile(uid: string): Promise<VChatUser | null> {
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (snap.exists()) {
      return snap.data() as VChatUser;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
    return null;
  }
}

export async function updateUserProfile(
  uid: string,
  updates: Partial<VChatUser>
): Promise<void> {
  try {
    const ref = doc(db, 'users', uid);
    await updateDoc(ref, {
      ...updates,
      updatedAt: new Date().toISOString(),
    });
    const publicUpdates: Record<string, unknown> = {};
    for (const key of ['fullName', 'username', 'profilePhotoUrl', 'bio', 'lastSeen', 'isOnline'] as const) {
      if (key in updates) publicUpdates[key] = updates[key];
    }
    if (Object.keys(publicUpdates).length) {
      await updateDoc(doc(db, 'publicUsers', uid), {
        ...publicUpdates,
        updatedAt: new Date().toISOString(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
  }
}

export async function logoutUser(uid?: string): Promise<void> {
  if (uid) {
    try {
      const lastSeen = new Date().toISOString();
      await updateDoc(doc(db, 'users', uid), { isOnline: false, lastSeen });
      await updateDoc(doc(db, 'publicUsers', uid), { isOnline: false, lastSeen });
    } catch {
      // ignore
    }
  }
  await signOut(auth);
}
