import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  limit,
  arrayUnion,
  increment,
} from 'firebase/firestore';
import { db } from './config';
import { handleFirestoreError, OperationType } from './error-handler';
import {
  VChatMessage,
  VChatRoom,
  VChatUser,
  MessageType,
  ReplyPreview,
  LocationData,
  ContactData,
} from '../types';

export function getDeterministicChatId(uid1: string, uid2: string): string {
  return [uid1, uid2].sort().join('_');
}

export async function getOrCreateDirectChat(
  currentUser: VChatUser,
  otherUser: VChatUser
): Promise<VChatRoom> {
  const chatId = getDeterministicChatId(currentUser.uid, otherUser.uid);
  const chatRef = doc(db, 'chats', chatId);

  try {
    const existingSnap = await getDoc(chatRef);
    if (existingSnap.exists()) {
      return existingSnap.data() as VChatRoom;
    }

    const newChat: VChatRoom = {
      chatId,
      participants: [currentUser.uid, otherUser.uid].sort(),
      participantDetails: {
        [currentUser.uid]: {
          uid: currentUser.uid,
          fullName: currentUser.fullName,
          username: currentUser.username,
          profilePhotoUrl: currentUser.profilePhotoUrl,
          isOnline: currentUser.isOnline ?? true,
          lastSeen: currentUser.lastSeen,
        },
        [otherUser.uid]: {
          uid: otherUser.uid,
          fullName: otherUser.fullName,
          username: otherUser.username,
          profilePhotoUrl: otherUser.profilePhotoUrl,
          isOnline: otherUser.isOnline ?? false,
          lastSeen: otherUser.lastSeen,
        },
      },
      lastMessage: 'Conversation started',
      lastMessageType: 'text',
      lastMessageTime: new Date().toISOString(),
      unreadCounts: {
        [currentUser.uid]: 0,
        [otherUser.uid]: 0,
      },
      typingStatus: {
        [currentUser.uid]: false,
        [otherUser.uid]: false,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await setDoc(chatRef, newChat, { merge: true });
    return newChat;
  } catch (error) {
    console.error('Could not create or open direct chat:', error);
    throw error;
  }
}

export function subscribeToUserChats(
  userId: string,
  onChatsUpdate: (chats: VChatRoom[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(
    collection(db, 'chats'),
    where('participants', 'array-contains', userId)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const rooms: VChatRoom[] = [];
      snapshot.forEach((docSnap) => {
        rooms.push(docSnap.data() as VChatRoom);
      });
      // Sort in memory by lastMessageTime descending
      rooms.sort((a, b) => {
        const timeA = new Date(a.lastMessageTime || a.createdAt).getTime();
        const timeB = new Date(b.lastMessageTime || b.createdAt).getTime();
        return timeB - timeA;
      });
      onChatsUpdate(rooms);
    },
    (error) => {
      if (typeof onError === 'function') {
        (onError as (err: Error) => void)(error as Error);
      }
      handleFirestoreError(error, OperationType.LIST, 'chats');
    }
  );
}

export function subscribeToMessages(
  chatId: string,
  onMessages: (msgs: VChatMessage[]) => void,
  onError?: (err: Error) => void
) {
  const messagesRef = collection(db, 'chats', chatId, 'messages');
  const q = query(messagesRef, orderBy('sentAt', 'asc'), limit(200));

  return onSnapshot(
    q,
    (snapshot) => {
      const messages: VChatMessage[] = [];
      snapshot.forEach((docSnap) => {
        messages.push(docSnap.data() as VChatMessage);
      });
      onMessages(messages);
    },
    (error) => {
      if (typeof onError === 'function') {
        (onError as (err: Error) => void)(error as Error);
      }
      console.warn(`Messages listener for ${chatId}:`, error);
    }
  );
}

export interface SendMessageParams {
  chatId: string;
  senderId: string;
  receiverId: string;
  messageText: string;
  messageType: MessageType;
  mediaUrl?: string;
  thumbnailUrl?: string;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  duration?: number;
  locationData?: LocationData;
  contactData?: ContactData;
  replyTo?: ReplyPreview;
}

export async function sendChatMessage(params: SendMessageParams): Promise<VChatMessage> {
  const messageId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const now = new Date().toISOString();

  const messageDoc: VChatMessage = {
    messageId,
    chatId: params.chatId,
    senderId: params.senderId,
    receiverId: params.receiverId,
    messageText: params.messageText.trim(),
    messageType: params.messageType,
    mediaUrl: params.mediaUrl,
    thumbnailUrl: params.thumbnailUrl,
    fileName: params.fileName,
    fileSize: params.fileSize,
    mimeType: params.mimeType,
    duration: params.duration,
    locationData: params.locationData,
    contactData: params.contactData,
    sentAt: now,
    status: 'sent',
    replyTo: params.replyTo,
    reactions: {},
    deletedFor: [],
    deletedForEveryone: false,
  };

  const msgRef = doc(db, 'chats', params.chatId, 'messages', messageId);
  const chatRef = doc(db, 'chats', params.chatId);

  try {
    // 1. Write the message document
    await setDoc(msgRef, messageDoc);

    // 2. Update chat room summary with merge: true for resilience
    let summaryText = params.messageText.trim();
    if (!summaryText) {
      if (params.messageType === 'image') summaryText = '📷 Photo';
      else if (params.messageType === 'video') summaryText = '🎥 Video';
      else if (params.messageType === 'voice') summaryText = '🎤 Voice note';
      else if (params.messageType === 'audio') summaryText = '🎵 Audio';
      else if (params.messageType === 'document') summaryText = `📄 ${params.fileName || 'Document'}`;
      else if (params.messageType === 'location') summaryText = '📍 Shared location';
      else if (params.messageType === 'contact') summaryText = `👤 Contact: ${params.contactData?.name || 'Contact'}`;
    }

    await setDoc(
      chatRef,
      {
        chatId: params.chatId,
        lastMessage: summaryText,
        lastMessageType: params.messageType,
        lastMessageTime: now,
        lastMessageSenderId: params.senderId,
        [`unreadCounts.${params.receiverId}`]: increment(1),
        [`typingStatus.${params.senderId}`]: false,
        updatedAt: now,
      },
      { merge: true }
    );

    return messageDoc;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `chats/${params.chatId}/messages/${messageId}`);
    throw error;
  }
}

export async function markChatAsRead(chatId: string, currentUserId: string): Promise<void> {
  const chatRef = doc(db, 'chats', chatId);
  try {
    await updateDoc(chatRef, {
      [`unreadCounts.${currentUserId}`]: 0,
    });
  } catch {
    // Non-critical read status update
  }
}

export async function toggleMessageReaction(
  chatId: string,
  messageId: string,
  emoji: string,
  userId: string
): Promise<void> {
  const msgRef = doc(db, 'chats', chatId, 'messages', messageId);
  try {
    const snap = await getDoc(msgRef);
    if (!snap.exists()) return;
    const data = snap.data() as VChatMessage;
    const currentReactions: { [key: string]: string[] } = data.reactions || {};

    const users = currentReactions[emoji] || [];
    if (users.includes(userId)) {
      currentReactions[emoji] = users.filter((u) => u !== userId);
      if (currentReactions[emoji].length === 0) {
        delete currentReactions[emoji];
      }
    } else {
      currentReactions[emoji] = [...users, userId];
    }

    await updateDoc(msgRef, {
      reactions: currentReactions,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}/messages/${messageId}`);
  }
}

export async function deleteMessageForEveryone(chatId: string, messageId: string): Promise<void> {
  const msgRef = doc(db, 'chats', chatId, 'messages', messageId);
  try {
    await updateDoc(msgRef, {
      deletedForEveryone: true,
      messageText: 'This message was deleted',
      mediaUrl: '',
      thumbnailUrl: '',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}/messages/${messageId}`);
  }
}

export async function deleteMessageForMe(
  chatId: string,
  messageId: string,
  userId: string
): Promise<void> {
  const msgRef = doc(db, 'chats', chatId, 'messages', messageId);
  try {
    await updateDoc(msgRef, {
      deletedFor: arrayUnion(userId),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}/messages/${messageId}`);
  }
}

export async function updateTypingStatus(
  chatId: string,
  userId: string,
  isTyping: boolean
): Promise<void> {
  const chatRef = doc(db, 'chats', chatId);
  try {
    await updateDoc(chatRef, {
      [`typingStatus.${userId}`]: isTyping,
    });
  } catch {
    // Non-critical presence update
  }
}

/**
 * Real-time subscription to all registered users for the Users / Contacts section
 */
export function subscribeToAllUsers(
  currentUserId: string,
  onUsers: (users: VChatUser[]) => void
) {
  const usersCol = collection(db, 'publicUsers');
  return onSnapshot(
    usersCol,
    (snapshot) => {
      const users: VChatUser[] = [];
      snapshot.forEach((d) => {
        const u = d.data() as VChatUser;
        if (
          u.uid &&
          u.uid !== currentUserId &&
          u.accountStatus !== 'suspended' &&
          u.accountStatus !== 'deleted'
        ) {
          users.push(u);
        }
      });
      // Sort online first, then by fullName
      users.sort((a, b) => {
        if (a.isOnline && !b.isOnline) return -1;
        if (!a.isOnline && b.isOnline) return 1;
        return (a.fullName || a.username || '').localeCompare(b.fullName || b.username || '');
      });
      onUsers(users);
    },
    (error) => {
      console.warn('subscribeToAllUsers notice:', error);
    }
  );
}

export async function searchAllUsers(searchTerm: string): Promise<VChatUser[]> {
  const term = searchTerm.trim().toLowerCase();
  if (!term) return [];
  try {
    const usersCol = collection(db, 'publicUsers');
    const snapshot = await getDocs(query(usersCol, limit(50)));
    const results: VChatUser[] = [];
    snapshot.forEach((d) => {
      const u = d.data() as VChatUser;
      if (
        u.username?.toLowerCase().includes(term) ||
        u.fullName?.toLowerCase().includes(term) ||
        u.email?.toLowerCase().includes(term)
      ) {
        results.push(u);
      }
    });
    return results;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
    return [];
  }
}
