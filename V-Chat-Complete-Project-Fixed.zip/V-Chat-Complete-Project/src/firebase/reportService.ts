import { doc, setDoc } from 'firebase/firestore';
import { db } from './config';
import { VChatReport } from '../types';

export async function submitReport(
  reporterId: string,
  targetType: 'user' | 'message' | 'group',
  targetId: string,
  reason: string,
  details = ''
): Promise<void> {
  const reportId = `rep_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const reportDoc: VChatReport = {
    reportId,
    reporterId,
    targetType,
    targetId,
    reason,
    details,
    createdAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'reports', reportId), reportDoc);
}
