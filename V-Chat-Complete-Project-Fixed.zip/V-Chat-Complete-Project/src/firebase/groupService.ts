import {
  collection,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  limit,
  arrayUnion,
  arrayRemove,
} from 'firebase/firestore';
import { db } from './config';
import { handleFirestoreError, OperationType } from './error-handler';
import { VChatGroup, VChatGroupMessage, VChatUser, MessageType } from '../types';

export async function createNewGroup(
  creator: VChatUser,
  groupName: string,
  description: string,
  memberIds: string[],
  groupPhoto?: string
): Promise<VChatGroup> {
  const groupId = `grp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const allMembers = Array.from(new Set([creator.uid, ...memberIds]));
  const now = new Date().toISOString();

  const groupData: VChatGroup = {
    groupId,
    groupName: groupName.trim(),
    description: description.trim(),
    groupPhoto: groupPhoto || `https://api.dicebear.com/7.x/identicon/svg?seed=${groupId}`,
    createdBy: creator.uid,
    admins: [creator.uid],
    members: allMembers,
    groupType: 'private',
    inviteLink: `https://vchat.app/join/${groupId}`,
    lastMessage: 'Group created',
    lastMessageType: 'text',
    lastMessageTime: now,
    createdAt: now,
    updatedAt: now,
  };

  const groupRef = doc(db, 'groups', groupId);
  try {
    await setDoc(groupRef, groupData);
    return groupData;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `groups/${groupId}`);
    throw error;
  }
}

export function subscribeToUserGroups(
  userId: string,
  onGroupsUpdate: (groups: VChatGroup[]) => void
) {
  const q = query(collection(db, 'groups'), where('members', 'array-contains', userId));
  return onSnapshot(
    q,
    (snapshot) => {
      const groups: VChatGroup[] = [];
      snapshot.forEach((snap) => {
        groups.push(snap.data() as VChatGroup);
      });
      groups.sort((a, b) => {
        const timeA = new Date(a.lastMessageTime || a.createdAt).getTime();
        const timeB = new Date(b.lastMessageTime || b.createdAt).getTime();
        return timeB - timeA;
      });
      onGroupsUpdate(groups);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'groups');
    }
  );
}

export function subscribeToGroupMessages(
  groupId: string,
  onMessages: (msgs: VChatGroupMessage[]) => void
) {
  const q = query(
    collection(db, 'groups', groupId, 'groupMessages'),
    orderBy('sentAt', 'asc'),
    limit(100)
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const messages: VChatGroupMessage[] = [];
      snapshot.forEach((snap) => {
        messages.push(snap.data() as VChatGroupMessage);
      });
      onMessages(messages);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, `groups/${groupId}/groupMessages`);
    }
  );
}

export async function sendGroupMessage(
  groupId: string,
  sender: VChatUser,
  messageText: string,
  messageType: MessageType = 'text',
  mediaUrl?: string,
  fileName?: string,
  fileSize?: number
): Promise<void> {
  const messageId = `gmsg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  const msgDoc: VChatGroupMessage = {
    messageId,
    groupId,
    senderId: sender.uid,
    senderName: sender.fullName,
    senderPhoto: sender.profilePhotoUrl,
    messageText: messageText.trim(),
    messageType,
    mediaUrl,
    fileName,
    fileSize,
    sentAt: now,
    reactions: {},
  };

  const msgRef = doc(db, 'groups', groupId, 'groupMessages', messageId);
  const groupRef = doc(db, 'groups', groupId);

  try {
    await setDoc(msgRef, msgDoc);
    await updateDoc(groupRef, {
      lastMessage: `${sender.fullName.split(' ')[0]}: ${messageText || messageType}`,
      lastMessageType: messageType,
      lastMessageTime: now,
      updatedAt: now,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `groups/${groupId}/groupMessages/${messageId}`);
    throw error;
  }
}
