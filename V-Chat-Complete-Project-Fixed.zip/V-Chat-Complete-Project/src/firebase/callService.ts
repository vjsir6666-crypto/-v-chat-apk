import { collection, doc, setDoc, updateDoc, onSnapshot, query, where, limit, getDocs } from 'firebase/firestore';
import { db } from './config';
import { VChatCall, VChatUser } from '../types';

export async function initiateCall(
  caller: VChatUser,
  receiver: VChatUser,
  callType: 'voice' | 'video'
): Promise<string> {
  const callId = `call_${Date.now()}_${caller.uid.substring(0, 5)}`;
  const callDoc: VChatCall = {
    callId,
    callerId: caller.uid,
    callerName: caller.fullName,
    callerPhoto: caller.profilePhotoUrl,
    receiverId: receiver.uid,
    receiverName: receiver.fullName,
    receiverPhoto: receiver.profilePhotoUrl,
    callType,
    status: 'ringing',
    createdAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'calls', callId), callDoc);
  return callId;
}

export function subscribeToIncomingCalls(
  currentUserId: string,
  onIncomingCall: (call: VChatCall | null) => void
) {
  const q = query(
    collection(db, 'calls'),
    where('receiverId', '==', currentUserId),
    where('status', '==', 'ringing'),
    limit(1)
  );

  return onSnapshot(q, (snapshot) => {
    if (snapshot.empty) {
      onIncomingCall(null);
    } else {
      const call = snapshot.docs[0].data() as VChatCall;
      onIncomingCall(call);
    }
  });
}

export async function answerCall(callId: string): Promise<void> {
  await updateDoc(doc(db, 'calls', callId), {
    status: 'accepted',
  });
}

export async function endCall(callId: string, durationSeconds?: number): Promise<void> {
  try {
    await updateDoc(doc(db, 'calls', callId), {
      status: 'ended',
      durationSeconds: durationSeconds || 0,
    });
  } catch {
    // Call might already be cleaned up
  }
}
