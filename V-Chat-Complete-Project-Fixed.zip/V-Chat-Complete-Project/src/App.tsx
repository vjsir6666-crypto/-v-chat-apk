/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, validateFirestoreConnection } from './firebase/config';
import {
  getUserProfile,
  logoutUser,
} from './firebase/authService';
import {
  getOrCreateDirectChat,
  subscribeToUserChats,
  subscribeToMessages,
  subscribeToAllUsers,
  sendChatMessage,
  markChatAsRead,
  toggleMessageReaction,
  deleteMessageForMe,
  deleteMessageForEveryone,
  updateTypingStatus,
} from './firebase/chatService';
import {
  subscribeToUserGroups,
  subscribeToGroupMessages,
  sendGroupMessage,
} from './firebase/groupService';
import {
  initiateCall,
  subscribeToIncomingCalls,
  answerCall,
  endCall,
} from './firebase/callService';
import { uploadMediaFile, compressImage } from './firebase/storageService';
import {
  VChatUser,
  VChatRoom,
  VChatMessage,
  VChatGroup,
  VChatCall,
  ReplyPreview,
} from './types';

// Components
import { Header } from './components/Header';
import { PeerStatusBar } from './components/PeerStatusBar';
import { MessageItem } from './components/MessageItem';
import { AttachmentDrawer } from './components/AttachmentDrawer';
import { ComposerBar } from './components/ComposerBar';
import { CameraCaptureModal } from './components/CameraCaptureModal';
import { ImageViewerModal } from './components/ImageViewerModal';
import { MediaPreviewModal } from './components/MediaPreviewModal';
import { CallModal } from './components/CallModal';
import { AuthModal } from './components/AuthModal';
import { ConversationsDrawer } from './components/ConversationsDrawer';
import { GroupCreateModal } from './components/GroupCreateModal';
import { ProfileModal } from './components/ProfileModal';
import { PrivacyModal } from './components/PrivacyModal';
import { ReportModal } from './components/ReportModal';

interface MediaFileItem {
  file: File;
  previewUrl: string;
  type: 'image' | 'video';
}

export default function App() {
  // Current authenticated user
  const [currentUser, setCurrentUser] = useState<VChatUser | null>(null);
  const [authChecking, setAuthChecking] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Registered Users Directory
  const [allRegisteredUsers, setAllRegisteredUsers] = useState<VChatUser[]>([]);

  // Active Chat State
  const [chats, setChats] = useState<VChatRoom[]>([]);
  const [activeChat, setActiveChat] = useState<VChatRoom | null>(null);
  const [peerUser, setPeerUser] = useState<VChatUser | null>(null);
  const [messages, setMessages] = useState<VChatMessage[]>([]);

  // Active Group State
  const [groups, setGroups] = useState<VChatGroup[]>([]);
  const [activeGroup, setActiveGroup] = useState<VChatGroup | null>(null);

  // Interaction & Modal States
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; fileName?: string } | null>(null);
  const [isConversationsOpen, setIsConversationsOpen] = useState(false);
  const [conversationsTab, setConversationsTab] = useState<'chats' | 'users' | 'groups'>('chats');
  const [isGroupCreateOpen, setIsGroupCreateOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ id: string; name: string; type: 'user' | 'message' | 'group' } | null>(null);

  // Media Preview State
  const [pendingMediaFiles, setPendingMediaFiles] = useState<MediaFileItem[]>([]);
  const [isMediaPreviewOpen, setIsMediaPreviewOpen] = useState(false);

  // Active Call State
  const [activeCall, setActiveCall] = useState<VChatCall | null>(null);
  const [isIncomingCall, setIsIncomingCall] = useState(false);

  // Composer reply state
  const [replyTo, setReplyTo] = useState<ReplyPreview | null>(null);

  // Network & Upload Progress
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  // Hidden File Inputs
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const documentInputRef = useRef<HTMLInputElement | null>(null);
  const audioInputRef = useRef<HTMLInputElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Show Toast Helper
  const showToast = (msg: string) => {
    setNotificationToast(msg);
    setTimeout(() => setNotificationToast(null), 3500);
  };

  // 1. Firebase Auth listener and session restoration
  useEffect(() => {
    validateFirestoreConnection();

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const profile = await getUserProfile(fbUser.uid);
          if (profile) {
            setCurrentUser(profile);
            setShowAuthModal(false);
          } else {
            const fallback: VChatUser = {
              uid: fbUser.uid,
              fullName: fbUser.displayName || 'V-CHAT User',
              username: (fbUser.email?.split('@')[0] || 'user').toLowerCase().replace(/[^a-z0-9_]/g, ''),
              email: fbUser.email || '',
              profilePhotoUrl:
                fbUser.photoURL ||
                `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
              bio: 'Available on V-CHAT',
              about: 'Hey there! I am using V-CHAT.',
              createdAt: new Date().toISOString(),
              isOnline: true,
              isVerified: true,
            };
            setCurrentUser(fallback);
            setShowAuthModal(false);
          }
        } catch {
          setShowAuthModal(true);
        }
      } else {
        setCurrentUser(null);
        setShowAuthModal(true);
      }
      setAuthChecking(false);
    });

    return () => unsubscribe();
  }, []);

  // 2. Real-time Subscriptions: Chats, Groups, Registered Users, Calls
  useEffect(() => {
    if (!currentUser) return;

    const unsubChats = subscribeToUserChats(currentUser.uid, (chatList) => {
      setChats(chatList);
    });

    const unsubGroups = subscribeToUserGroups(currentUser.uid, (groupList) => {
      setGroups(groupList);
    });

    const unsubUsers = subscribeToAllUsers(currentUser.uid, (userList) => {
      setAllRegisteredUsers(userList);
    });

    const unsubCalls = subscribeToIncomingCalls(currentUser.uid, (incoming) => {
      if (incoming) {
        setActiveCall(incoming);
        setIsIncomingCall(true);
      }
    });

    return () => {
      unsubChats();
      unsubGroups();
      unsubUsers();
      unsubCalls();
    };
  }, [currentUser]);

  // 3. Open or Restore Active Chat
  useEffect(() => {
    if (!currentUser || activeChat || activeGroup) return;

    // If user has existing chats, open the most recent one
    if (chats.length > 0) {
      const topChat = chats[0];
      setActiveChat(topChat);
      const otherUid = topChat.participants.find((p) => p !== currentUser.uid) || '';
      const details = topChat.participantDetails?.[otherUid];
      if (details) {
        setPeerUser({
          uid: details.uid,
          fullName: details.fullName,
          username: details.username,
          email: '',
          profilePhotoUrl: details.profilePhotoUrl,
          isOnline: details.isOnline,
          lastSeen: details.lastSeen,
          createdAt: '',
        });
      }
    }
  }, [currentUser, chats]);

  // 4. Real-time Messages Listener for Active Chat
  useEffect(() => {
    if (!activeChat || !currentUser) return;

    // Reset unread count for current user
    markChatAsRead(activeChat.chatId, currentUser.uid);

    const unsubMessages = subscribeToMessages(
      activeChat.chatId,
      (msgList) => {
        setMessages(msgList);
      },
      (err) => {
        console.warn('Messages subscription notice:', err);
      }
    );

    return () => unsubMessages();
  }, [activeChat?.chatId, currentUser?.uid]);

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Start or Open Chat with a selected User
  const handleStartChatWithUser = async (user: VChatUser) => {
    if (!currentUser) return;
    try {
      const room = await getOrCreateDirectChat(currentUser, user);
      setActiveChat(room);
      setActiveGroup(null);
      setPeerUser(user);
    } catch (err) {
      console.error('Failed to start chat:', err);
      showToast('Could not open this chat. Check your Firebase connection and permissions.');
    }
  };

  // Handle Send Text Message (Firestore Sync)
  const handleSendMessage = async (text: string): Promise<boolean> => {
    const cleanText = text.trim();
    if (!cleanText) return false;

    if (!currentUser) {
      showToast('Please sign in to send messages.');
      setShowAuthModal(true);
      return false;
    }

    // A conversation must be selected before sending. Avoid using stale React state
    // immediately after setActiveChat(), which previously caused sends to fail.
    if (!activeChat || !peerUser) {
      setConversationsTab('users');
      setIsConversationsOpen(true);
      showToast('Please select a registered user first, then send your message.');
      return false;
    }

    const currentChat = activeChat;
    const currentPeer = peerUser;
    const pendingReply = replyTo;
    const tempId = `temp_${Date.now()}`;
    const optimisticMsg: VChatMessage = {
      messageId: tempId,
      chatId: currentChat.chatId,
      senderId: currentUser.uid,
      receiverId: currentPeer.uid,
      messageText: cleanText,
      messageType: 'text',
      sentAt: new Date().toISOString(),
      status: 'sending',
      replyTo: pendingReply || undefined,
      reactions: {},
    };

    setMessages((prev) => [...prev, optimisticMsg]);
    setReplyTo(null);

    try {
      await sendChatMessage({
        chatId: currentChat.chatId,
        senderId: currentUser.uid,
        receiverId: currentPeer.uid,
        messageText: cleanText,
        messageType: 'text',
        replyTo: pendingReply || undefined,
      });
      return true;
    } catch (err) {
      console.error('Send message error:', err);
      setMessages((prev) => prev.filter((message) => message.messageId !== tempId));
      setReplyTo(pendingReply);
      showToast('Message was not sent. Check Firebase connection and permissions, then try again.');
      return false;
    }
  };

  // Handle Send Voice Note
  const handleSendVoiceNote = async (blob: Blob, durationSeconds: number) => {
    if (!currentUser || !activeChat || !peerUser) return;
    setIsUploading(true);
    setUploadProgress(15);
    try {
      const url = await uploadMediaFile(
        blob,
        `chats/${activeChat.chatId}/audio/voice_${Date.now()}.webm`,
        (p) => setUploadProgress(p)
      );
      await sendChatMessage({
        chatId: activeChat.chatId,
        senderId: currentUser.uid,
        receiverId: peerUser.uid,
        messageText: '',
        messageType: 'voice',
        mediaUrl: url,
        duration: durationSeconds,
      });
      showToast('Voice note sent!');
    } catch {
      showToast('Failed to send voice note.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  // Handle Gallery Selection -> Open Preview Modal
  const handleGallerySelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const items: MediaFileItem[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isVideo = file.type.startsWith('video');
      items.push({
        file,
        previewUrl: URL.createObjectURL(file),
        type: isVideo ? 'video' : 'image',
      });
    }

    setPendingMediaFiles(items);
    setIsMediaPreviewOpen(true);
    if (galleryInputRef.current) galleryInputRef.current.value = '';
  };

  // Handle Send Media from Preview Modal
  const handleSendPendingMedia = async (mediaList: MediaFileItem[], caption: string) => {
    if (!currentUser || !activeChat || !peerUser) return;
    setIsUploading(true);

    try {
      for (let i = 0; i < mediaList.length; i++) {
        const item = mediaList[i];
        setUploadProgress(10 + Math.round((i / mediaList.length) * 40));

        let fileToUpload: Blob = item.file;
        if (item.type === 'image') {
          fileToUpload = await compressImage(item.file, 1600, 1600, 0.85);
        }

        const path = `chats/${activeChat.chatId}/${item.type === 'video' ? 'videos' : 'images'}/${Date.now()}_${item.file.name}`;
        const downloadUrl = await uploadMediaFile(fileToUpload, path, (p) => {
          setUploadProgress(Math.round(((i + p / 100) / mediaList.length) * 100));
        });

        await sendChatMessage({
          chatId: activeChat.chatId,
          senderId: currentUser.uid,
          receiverId: peerUser.uid,
          messageText: i === 0 ? caption : '',
          messageType: item.type,
          mediaUrl: downloadUrl,
          fileName: item.file.name,
          fileSize: item.file.size,
          mimeType: item.file.type,
        });
      }

      showToast(mediaList.length > 1 ? 'Photos & videos sent!' : 'Media sent!');
      setIsMediaPreviewOpen(false);
      setPendingMediaFiles([]);
    } catch (err) {
      console.error('Media upload error:', err);
      showToast('Failed to upload media. Please try again.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  // Handle Camera Capture Send
  const handleCameraCaptureAndSend = async (blob: Blob, caption: string) => {
    if (!currentUser || !activeChat || !peerUser) return;
    setIsUploading(true);
    setUploadProgress(20);
    try {
      const url = await uploadMediaFile(
        blob,
        `chats/${activeChat.chatId}/images/cam_${Date.now()}.jpg`,
        (p) => setUploadProgress(p)
      );
      await sendChatMessage({
        chatId: activeChat.chatId,
        senderId: currentUser.uid,
        receiverId: peerUser.uid,
        messageText: caption,
        messageType: 'image',
        mediaUrl: url,
        fileName: `camera_${Date.now()}.jpg`,
      });
      showToast('Photo sent!');
    } catch {
      showToast('Failed to send photo from camera.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  // Handle Document Upload
  const handleDocumentSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser || !activeChat || !peerUser) return;

    setIsUploading(true);
    setUploadProgress(20);
    try {
      const url = await uploadMediaFile(
        file,
        `chats/${activeChat.chatId}/documents/${Date.now()}_${file.name}`,
        (p) => setUploadProgress(p)
      );
      await sendChatMessage({
        chatId: activeChat.chatId,
        senderId: currentUser.uid,
        receiverId: peerUser.uid,
        messageText: '',
        messageType: 'document',
        mediaUrl: url,
        fileName: file.name,
        fileSize: file.size,
        mimeType: file.type,
      });
      showToast('Document sent!');
    } catch {
      showToast('Failed to upload document.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      if (documentInputRef.current) documentInputRef.current.value = '';
    }
  };

  // Handle Audio Upload
  const handleAudioSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser || !activeChat || !peerUser) return;

    setIsUploading(true);
    setUploadProgress(20);
    try {
      const url = await uploadMediaFile(
        file,
        `chats/${activeChat.chatId}/audio/${Date.now()}_${file.name}`,
        (p) => setUploadProgress(p)
      );
      await sendChatMessage({
        chatId: activeChat.chatId,
        senderId: currentUser.uid,
        receiverId: peerUser.uid,
        messageText: '',
        messageType: 'audio',
        mediaUrl: url,
        fileName: file.name,
        fileSize: file.size,
      });
      showToast('Audio track sent!');
    } catch {
      showToast('Failed to upload audio.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      if (audioInputRef.current) audioInputRef.current.value = '';
    }
  };

  // Handle Location Share
  const handleShareLocation = () => {
    if (!navigator.geolocation) {
      showToast('Geolocation is not supported by your browser.');
      return;
    }
    showToast('Acquiring GPS location...');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        if (!currentUser || !activeChat || !peerUser) return;
        try {
          await sendChatMessage({
            chatId: activeChat.chatId,
            senderId: currentUser.uid,
            receiverId: peerUser.uid,
            messageText: 'Shared location',
            messageType: 'location',
            locationData: {
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
              name: 'Current Device Location',
            },
          });
          showToast('Location shared!');
        } catch {
          showToast('Failed to share location.');
        }
      },
      () => {
        showToast('Unable to retrieve location. Please check browser permission.');
      }
    );
  };

  // Handle Contact Share
  const handleShareContact = async () => {
    if (!currentUser || !activeChat || !peerUser) return;
    const name = window.prompt('Enter Contact Name:', 'Sarah Connor');
    if (!name) return;
    const phone = window.prompt('Enter Phone Number:', '+1 555-0192') || '+1 555-0192';

    try {
      await sendChatMessage({
        chatId: activeChat.chatId,
        senderId: currentUser.uid,
        receiverId: peerUser.uid,
        messageText: '',
        messageType: 'contact',
        contactData: {
          name,
          phoneNumber: phone,
        },
      });
      showToast('Contact shared!');
    } catch {
      showToast('Failed to share contact.');
    }
  };

  // Voice/Video Call Handlers
  const handleStartCall = async (type: 'voice' | 'video') => {
    if (!currentUser || !peerUser) return;
    try {
      const callId = await initiateCall(currentUser, peerUser, type);
      setActiveCall({
        callId,
        callerId: currentUser.uid,
        callerName: currentUser.fullName,
        callerPhoto: currentUser.profilePhotoUrl,
        receiverId: peerUser.uid,
        receiverName: peerUser.fullName,
        receiverPhoto: peerUser.profilePhotoUrl,
        callType: type,
        status: 'ringing',
        createdAt: new Date().toISOString(),
      });
      setIsIncomingCall(false);
    } catch {
      showToast('Failed to start call.');
    }
  };

  // Reactions & Deletions
  const handleReaction = async (messageId: string, emoji: string) => {
    if (!activeChat || !currentUser) return;
    await toggleMessageReaction(activeChat.chatId, messageId, emoji, currentUser.uid);
  };

  const handleDeleteForMe = async (messageId: string) => {
    if (!activeChat || !currentUser) return;
    await deleteMessageForMe(activeChat.chatId, messageId, currentUser.uid);
    showToast('Message removed for you.');
  };

  const handleDeleteForEveryone = async (messageId: string) => {
    if (!activeChat) return;
    await deleteMessageForEveryone(activeChat.chatId, messageId);
    showToast('Message deleted for everyone.');
  };

  // Typing presence
  const handleTypingPresence = (isTyping: boolean) => {
    if (!activeChat || !currentUser) return;
    updateTypingStatus(activeChat.chatId, currentUser.uid, isTyping);
  };

  // Check peer typing
  const isPeerTyping =
    peerUser && activeChat?.typingStatus?.[peerUser.uid] ? true : false;

  // Render splash during auth initialization
  if (authChecking) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-surface">
        <img
          alt="V-CHAT"
          className="h-12 w-auto mb-4 animate-pulse"
          src="https://lh3.googleusercontent.com/aida/AEtjO1XJLq4eXvG5vN8KHZd8xZ6dRZi7A-D3ncF4PMw4GL-yv5GnaLw0xk6uezSqrnz-nawi-4oPD-vEVC53kVBNdUuW4qjOjqvHvki2VQn14h_6wWXGpVpTmgpRv9SNkDlxldU0MhgCfAPn1WdQG0PyPtyshJjzbPr76A6Dm9Cj1JBv9A0AkdO2EGz0nrzlDAu8VT_pzviQVGncf-aERFJefNVwV8uepY8vXqZIMt7ir5YYvw"
        />
        <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-surface font-sans text-on-surface antialiased flex flex-col min-h-screen">
      {/* Toast Notification Banner */}
      {notificationToast && (
        <div className="fixed top-18 inset-x-0 mx-auto max-w-sm px-4 z-50 animate-slideDown">
          <div className="bg-inverse-surface/90 text-inverse-on-surface px-4 py-2.5 rounded-full shadow-lg text-xs font-semibold flex items-center justify-between backdrop-blur-md">
            <span>{notificationToast}</span>
            <button
              onClick={() => setNotificationToast(null)}
              className="text-white/60 hover:text-white ml-2"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>
        </div>
      )}

      {/* Upload Progress Banner */}
      {isUploading && (
        <div className="fixed top-16 inset-x-0 bg-primary text-white text-xs py-1 px-4 z-40 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
            <span>Uploading to Firebase... {uploadProgress > 0 ? `${uploadProgress}%` : ''}</span>
          </div>
          <div className="w-24 bg-white/20 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-white h-full transition-all duration-200"
              style={{ width: `${Math.max(uploadProgress, 20)}%` }}
            />
          </div>
        </div>
      )}

      {/* Top Header */}
      <Header
        currentUser={currentUser}
        title={peerUser?.fullName || 'V-CHAT'}
        showBack={false}
        onOpenConversations={() => {
          setConversationsTab('chats');
          setIsConversationsOpen(true);
        }}
        onOpenNewChat={() => {
          setConversationsTab('users');
          setIsConversationsOpen(true);
        }}
        onOpenNewGroup={() => setIsGroupCreateOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onSwitchUser={() => setShowAuthModal(true)}
        onLogout={async () => {
          if (currentUser) await logoutUser(currentUser.uid);
          setCurrentUser(null);
          setActiveChat(null);
          setPeerUser(null);
          setMessages([]);
          setShowAuthModal(true);
        }}
      />

      {/* Main Container */}
      <main className="flex-1 w-full bg-surface pt-16 flex flex-col max-w-4xl mx-auto">
        {peerUser ? (
          /* Floating Active Call & Peer Status Banner */
          <PeerStatusBar
            peerUser={peerUser}
            isTyping={isPeerTyping}
            onStartVoiceCall={() => handleStartCall('voice')}
            onStartVideoCall={() => handleStartCall('video')}
            onViewProfile={() => {
              showToast(`Viewing @${peerUser.username} (${peerUser.fullName})`);
            }}
            onBlockUser={() => showToast(`${peerUser.fullName} has been blocked.`)}
            onReportUser={() => {
              setReportTarget({
                id: peerUser.uid,
                name: peerUser.fullName,
                type: 'user',
              });
            }}
            onClearChat={() => {
              if (window.confirm('Clear messages view?')) {
                setMessages([]);
                showToast('Messages view cleared.');
              }
            }}
          />
        ) : (
          <div className="p-4 bg-surface-container-low border-b border-surface-container flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-on-surface">No Chat Selected</h2>
              <p className="text-xs text-on-surface-variant">Select or search for a registered user to start messaging.</p>
            </div>
            <button
              onClick={() => {
                setConversationsTab('users');
                setIsConversationsOpen(true);
              }}
              className="py-1.5 px-3.5 bg-primary text-white text-xs font-semibold rounded-full shadow-sm flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">person_search</span>
              <span>Find Users</span>
            </button>
          </div>
        )}

        {/* Chat Canvas Feed Area */}
        <div className="flex-1 px-4 flex flex-col pt-3 pb-28 space-y-3 overflow-y-auto">
          {/* Security & Encryption Notice */}
          <div className="flex flex-col items-center justify-center gap-1.5 py-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container text-on-surface-variant shadow-xs max-w-xs text-center">
              <span
                className="material-symbols-outlined text-[14px] text-tertiary"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                lock
              </span>
              <span className="text-[11px]">Messages & calls are end-to-end encrypted.</span>
            </div>
          </div>

          {/* Empty Chat State if no messages yet */}
          {messages.length === 0 && peerUser && (
            <div className="flex flex-col items-center justify-center py-12 text-center text-on-surface-variant">
              <img
                src={
                  peerUser.profilePhotoUrl ||
                  `https://api.dicebear.com/7.x/avataaars/svg?seed=${peerUser.username}`
                }
                alt={peerUser.fullName}
                className="w-16 h-16 rounded-full object-cover mb-2 shadow-sm ring-2 ring-primary/20"
              />
              <h3 className="font-bold text-sm text-on-surface">{peerUser.fullName}</h3>
              <p className="text-xs text-primary font-semibold mb-1">@{peerUser.username}</p>
              <p className="text-xs max-w-xs text-outline">
                This is the beginning of your direct conversation with {peerUser.fullName.split(' ')[0]}. Say hello! 👋
              </p>
            </div>
          )}

          {/* Messages Feed */}
          {messages.map((msg) => {
            const isMe = msg.senderId === currentUser?.uid;
            return (
              <MessageItem
                key={msg.messageId}
                message={msg}
                isCurrentUser={isMe}
                senderUser={isMe ? currentUser : peerUser}
                onImageClick={(url, name) => setLightboxImage({ url, fileName: name })}
                onReply={(m) =>
                  setReplyTo({
                    messageId: m.messageId,
                    senderId: m.senderId,
                    senderName: isMe ? 'You' : peerUser?.fullName || 'User',
                    messageText: m.messageText,
                    messageType: m.messageType,
                  })
                }
                onReaction={handleReaction}
                onDeleteForMe={handleDeleteForMe}
                onDeleteForEveryone={handleDeleteForEveryone}
              />
            );
          })}

          {/* Live Typing Indicator Bubble */}
          {isPeerTyping && peerUser && (
            <div className="flex items-end gap-2 max-w-[85%] animate-fadeIn">
              <img
                className="w-7 h-7 rounded-full object-cover flex-shrink-0 mb-1 ring-1 ring-black/5"
                alt={peerUser.fullName}
                src={
                  peerUser.profilePhotoUrl ||
                  `https://api.dicebear.com/7.x/avataaars/svg?seed=${peerUser.username}`
                }
              />
              <div className="bg-surface-container-lowest px-4 py-3 rounded-2xl rounded-bl-sm shadow-sm border border-surface-container/60 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-primary/70 animate-bounce" style={{ animationDelay: '0s' }} />
                <span className="w-2 h-2 rounded-full bg-primary/70 animate-bounce" style={{ animationDelay: '0.18s' }} />
                <span className="w-2 h-2 rounded-full bg-primary/70 animate-bounce" style={{ animationDelay: '0.36s' }} />
                <span className="text-xs text-on-surface-variant ml-2 font-medium">
                  {peerUser.fullName.split(' ')[0]} is typing...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Slide-up Attachment Drawer */}
        <AttachmentDrawer
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          onSelectGallery={() => galleryInputRef.current?.click()}
          onSelectCamera={() => setIsCameraOpen(true)}
          onSelectDocument={() => documentInputRef.current?.click()}
          onSelectAudio={() => audioInputRef.current?.click()}
          onSelectLocation={handleShareLocation}
          onSelectContact={handleShareContact}
        />

        {/* Bottom Message Composer Bar (Always visible with Send button) */}
        <ComposerBar
          onSendMessage={handleSendMessage}
          onSendVoiceNote={handleSendVoiceNote}
          onToggleDrawer={() => setIsDrawerOpen(!isDrawerOpen)}
          onQuickCamera={() => setIsCameraOpen(true)}
          replyTo={replyTo}
          onCancelReply={() => setReplyTo(null)}
          onTyping={handleTypingPresence}
        />
      </main>

      {/* Hidden File Inputs */}
      <input
        ref={galleryInputRef}
        type="file"
        multiple
        accept="image/*,video/*"
        onChange={handleGallerySelected}
        className="hidden"
      />
      <input
        ref={documentInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.zip"
        onChange={handleDocumentSelected}
        className="hidden"
      />
      <input
        ref={audioInputRef}
        type="file"
        accept="audio/*"
        onChange={handleAudioSelected}
        className="hidden"
      />

      {/* Modals & Dialogs */}
      <AuthModal
        isOpen={showAuthModal}
        onSuccess={(user) => {
          setCurrentUser(user);
          setShowAuthModal(false);
          showToast(`Welcome, ${user.fullName}!`);
        }}
      />

      {/* Photo & Video Preview Modal */}
      <MediaPreviewModal
        isOpen={isMediaPreviewOpen}
        mediaFiles={pendingMediaFiles}
        onClose={() => {
          setIsMediaPreviewOpen(false);
          setPendingMediaFiles([]);
        }}
        onSend={handleSendPendingMedia}
        onRemoveItem={(index) => {
          setPendingMediaFiles((prev) => prev.filter((_, i) => i !== index));
          if (pendingMediaFiles.length <= 1) {
            setIsMediaPreviewOpen(false);
          }
        }}
        isUploading={isUploading}
        uploadProgress={uploadProgress}
      />

      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCaptureAndSend={handleCameraCaptureAndSend}
      />

      <ImageViewerModal
        isOpen={!!lightboxImage}
        imageUrl={lightboxImage?.url || null}
        fileName={lightboxImage?.fileName}
        onClose={() => setLightboxImage(null)}
        onForward={() => {
          setLightboxImage(null);
          showToast('Forwarded photo to active conversation.');
        }}
      />

      <CallModal
        call={activeCall}
        isIncoming={isIncomingCall}
        onAccept={async () => {
          if (activeCall) await answerCall(activeCall.callId);
          setIsIncomingCall(false);
        }}
        onDecline={async () => {
          if (activeCall) await endCall(activeCall.callId, 0);
          setActiveCall(null);
          setIsIncomingCall(false);
        }}
        onEnd={async (durationSec) => {
          if (activeCall) await endCall(activeCall.callId, durationSec);
          setActiveCall(null);
          setIsIncomingCall(false);
          showToast(`Call ended (${Math.floor(durationSec / 60)}m ${durationSec % 60}s)`);
        }}
      />

      <ConversationsDrawer
        isOpen={isConversationsOpen}
        onClose={() => setIsConversationsOpen(false)}
        currentUser={currentUser || ({} as any)}
        chats={chats}
        groups={groups}
        allRegisteredUsers={allRegisteredUsers}
        activeChatId={activeChat?.chatId || null}
        initialTab={conversationsTab}
        onSelectChat={(chat) => {
          setActiveChat(chat);
          setActiveGroup(null);
          const otherUid = chat.participants.find((p) => p !== currentUser?.uid) || '';
          const details = chat.participantDetails?.[otherUid];
          if (details) {
            setPeerUser({
              uid: details.uid,
              fullName: details.fullName,
              username: details.username,
              email: '',
              profilePhotoUrl: details.profilePhotoUrl,
              isOnline: details.isOnline,
              lastSeen: details.lastSeen,
              createdAt: '',
            });
          }
        }}
        onSelectGroup={(grp) => {
          setActiveGroup(grp);
          showToast(`Switched to group: ${grp.groupName}`);
        }}
        onStartChatWithUser={(user) => {
          handleStartChatWithUser(user);
          showToast(`Chat started with ${user.fullName}`);
        }}
        onNewGroupClick={() => {
          setIsConversationsOpen(false);
          setIsGroupCreateOpen(true);
        }}
      />

      {currentUser && (
        <>
          <GroupCreateModal
            isOpen={isGroupCreateOpen}
            currentUser={currentUser}
            onClose={() => setIsGroupCreateOpen(false)}
            onGroupCreated={(newGrp) => {
              setActiveGroup(newGrp);
              showToast(`Group "${newGrp.groupName}" created!`);
            }}
          />

          <ProfileModal
            isOpen={isProfileOpen}
            currentUser={currentUser}
            onClose={() => setIsProfileOpen(false)}
            onUpdate={(updated) => {
              setCurrentUser(updated);
              showToast('Profile updated!');
            }}
            onDeleteAccount={async () => {
              await logoutUser(currentUser.uid);
              setCurrentUser(null);
              setIsProfileOpen(false);
              setShowAuthModal(true);
              showToast('Account deleted.');
            }}
          />

          <PrivacyModal
            isOpen={isPrivacyOpen}
            onClose={() => setIsPrivacyOpen(false)}
          />

          {reportTarget && (
            <ReportModal
              isOpen={!!reportTarget}
              reporterId={currentUser.uid}
              targetType={reportTarget.type}
              targetId={reportTarget.id}
              targetName={reportTarget.name}
              onClose={() => setReportTarget(null)}
            />
          )}
        </>
      )}
    </div>
  );
}
