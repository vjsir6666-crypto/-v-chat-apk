import React, { useRef, useState, useEffect } from 'react';

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCaptureAndSend: (imageBlob: Blob, caption: string) => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCaptureAndSend,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [capturedBlob, setCapturedBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }
    startCamera();
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const startCamera = async () => {
    stopCamera();
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (err) {
      console.warn('Camera error:', err);
      setCameraError('Camera access not available or permission denied.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(
      (blob) => {
        if (blob) {
          setCapturedBlob(blob);
          setPreviewUrl(URL.createObjectURL(blob));
          stopCamera();
        }
      },
      'image/jpeg',
      0.85
    );
  };

  const retake = () => {
    setCapturedBlob(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    startCamera();
  };

  const handleSend = () => {
    if (!capturedBlob) return;
    onCaptureAndSend(capturedBlob, caption);
    handleClose();
  };

  const handleClose = () => {
    stopCamera();
    setCapturedBlob(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setCaption('');
    onClose();
  };

  const toggleCameraFacing = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex flex-col justify-between p-4 animate-fadeIn">
      {/* Top Header */}
      <div className="flex items-center justify-between text-white z-10">
        <button
          onClick={handleClose}
          className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
        >
          <span className="material-symbols-outlined text-[24px]">close</span>
        </button>

        <span className="font-semibold text-base">
          {previewUrl ? 'Photo Preview' : 'Camera'}
        </span>

        {!previewUrl && (
          <button
            onClick={toggleCameraFacing}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            title="Switch Camera"
          >
            <span className="material-symbols-outlined text-[24px]">flip_camera_ios</span>
          </button>
        )}
      </div>

      {/* Camera Viewport or Captured Preview */}
      <div className="flex-1 flex items-center justify-center overflow-hidden my-4 relative rounded-2xl bg-black">
        {cameraError ? (
          <div className="text-center p-6 text-white/80 flex flex-col items-center gap-3">
            <span className="material-symbols-outlined text-[48px] text-error">videocam_off</span>
            <p className="text-sm">{cameraError}</p>
            <label className="mt-2 px-4 py-2 bg-primary text-white text-xs font-semibold rounded-full cursor-pointer">
              Choose from Gallery Instead
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setCapturedBlob(file);
                    setPreviewUrl(URL.createObjectURL(file));
                    setCameraError(null);
                  }
                }}
              />
            </label>
          </div>
        ) : previewUrl ? (
          <img
            src={previewUrl}
            alt="Preview"
            className="max-h-full max-w-full object-contain rounded-2xl"
          />
        ) : (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover rounded-2xl transform scale-x-[-1]"
          />
        )}
      </div>

      {/* Bottom Controls */}
      <div className="flex flex-col gap-3 max-w-md mx-auto w-full z-10">
        {previewUrl ? (
          <div className="flex flex-col gap-2">
            <input
              type="text"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Add a caption..."
              className="w-full bg-white/20 text-white placeholder-white/60 px-4 py-2.5 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary backdrop-blur-md"
            />
            <div className="flex items-center justify-between gap-4 mt-1">
              <button
                onClick={retake}
                className="flex-1 py-3 bg-white/20 hover:bg-white/30 text-white rounded-full font-semibold text-sm transition-colors"
              >
                Retake
              </button>
              <button
                onClick={handleSend}
                className="flex-1 py-3 bg-gradient-to-r from-primary-container to-secondary text-white rounded-full font-semibold text-sm shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-transform"
              >
                <span>Send Photo</span>
                <span className="material-symbols-outlined text-[18px]">send</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center py-4">
            <button
              onClick={capturePhoto}
              disabled={!!cameraError}
              aria-label="Capture Photo"
              className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center active:scale-90 transition-transform shadow-xl"
            >
              <div className="w-16 h-16 rounded-full bg-white hover:bg-white/90 transition-colors" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
