import React, { useState, useEffect } from 'react';
import { VChatUser, VChatGroup } from '../types';
import { createNewGroup } from '../firebase/groupService';
import { searchAllUsers } from '../firebase/chatService';

interface GroupCreateModalProps {
  isOpen: boolean;
  currentUser: VChatUser;
  onClose: () => void;
  onGroupCreated: (group: VChatGroup) => void;
}

export const GroupCreateModal: React.FC<GroupCreateModalProps> = ({
  isOpen,
  currentUser,
  onClose,
  onGroupCreated,
}) => {
  const [groupName, setGroupName] = useState('');
  const [description, setDescription] = useState('');
  const [availableUsers, setAvailableUsers] = useState<VChatUser[]>([]);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadUsers();
    }
  }, [isOpen]);

  const loadUsers = async () => {
    try {
      const users = await searchAllUsers(' ');
      setAvailableUsers(users.filter((u) => u.uid !== currentUser.uid));
    } catch {
      // ignore
    }
  };

  const toggleSelect = (uid: string) => {
    setSelectedUserIds((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) {
      setErrorMsg('Please enter a group name.');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const group = await createNewGroup(
        currentUser,
        groupName.trim(),
        description.trim(),
        selectedUserIds
      );
      onGroupCreated(group);
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to create group');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-surface-container-lowest max-w-md w-full rounded-3xl shadow-2xl p-6 border border-surface-container-high animate-scaleUp">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-secondary text-[24px]">group_add</span>
            <h3 className="font-bold text-lg text-on-surface">New Group Chat</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {errorMsg && (
          <div className="mb-3 p-2.5 rounded-xl bg-error-container/40 text-error text-xs">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleCreate} className="flex flex-col gap-3">
          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Group Name *</label>
            <input
              type="text"
              required
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="e.g. Design Systems & Engineering"
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Description</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Topic, guidelines, links..."
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">
              Add Members ({selectedUserIds.length} selected)
            </label>
            <div className="max-h-36 overflow-y-auto border border-surface-container-high rounded-xl p-2 space-y-1">
              {availableUsers.length === 0 ? (
                <p className="text-xs text-outline text-center py-3">No other registered users found yet.</p>
              ) : (
                availableUsers.map((user) => {
                  const isChecked = selectedUserIds.includes(user.uid);
                  return (
                    <div
                      key={user.uid}
                      onClick={() => toggleSelect(user.uid)}
                      className={`flex items-center gap-2.5 p-1.5 rounded-lg cursor-pointer transition-colors ${
                        isChecked ? 'bg-secondary/10' : 'hover:bg-surface-container-low'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        className="rounded text-secondary focus:ring-secondary"
                      />
                      <img
                        src={user.profilePhotoUrl || 'https://api.dicebear.com/7.x/avataaars/svg'}
                        alt={user.fullName}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-xs font-semibold truncate block">{user.fullName}</span>
                        <span className="text-[10px] text-on-surface-variant truncate block">@{user.username}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-secondary to-primary-container text-white font-semibold text-xs shadow-md mt-2 flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
          >
            {isLoading ? 'Creating Group...' : 'Create Group'}
          </button>
        </form>
      </div>
    </div>
  );
};
