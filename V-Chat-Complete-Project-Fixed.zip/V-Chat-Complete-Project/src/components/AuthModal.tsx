import React, { useState } from 'react';
import {
  registerUser,
  loginWithEmail,
  loginWithGoogle,
  resetUserPassword,
  checkUsernameAvailable,
} from '../firebase/authService';
import { VChatUser } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onSuccess: (user: VChatUser) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');

  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+1');
  const [bio, setBio] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(true);

  // States
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');

  if (!isOpen) return null;

  const handleCheckUsername = async (name: string) => {
    setUsername(name);
    const clean = name.trim().toLowerCase();
    if (clean.length < 2) {
      setUsernameStatus('idle');
      return;
    }
    setUsernameStatus('checking');
    try {
      const isAvailable = await checkUsernameAvailable(clean);
      setUsernameStatus(isAvailable ? 'available' : 'taken');
    } catch {
      setUsernameStatus('idle');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    if (!email.trim() || !password) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await loginWithEmail(email, password);
      onSuccess(user);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Invalid credentials. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!fullName.trim() || !username.trim() || !email.trim() || !password) {
      setErrorMsg('Please fill in all required fields.');
      return;
    }

    if (usernameStatus === 'taken') {
      setErrorMsg('The selected username is already taken. Please choose another.');
      return;
    }

    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    if (!termsAccepted) {
      setErrorMsg('You must agree to the Terms of Service & Privacy Policy.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await registerUser({
        fullName,
        username,
        email,
        phoneNumber,
        countryCode,
        password,
        bio: bio || 'Available on V-CHAT',
      });
      setSuccessMsg('Account registered successfully in Firebase!');
      setTimeout(() => {
        onSuccess(user);
      }, 600);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Registration failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setIsLoading(true);
    try {
      const user = await loginWithGoogle();
      onSuccess(user);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Google sign-in was cancelled or failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('Please enter your email address to receive password reset link.');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      await resetUserPassword(email);
      setSuccessMsg(`Password reset email sent to ${email}. Check your inbox!`);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to send reset email.');
    } finally {
      setIsLoading(false);
    }
  };

  // Helper to test User A and User B scenario via Real Firebase
  const quickAuthRealUser = async (target: 'userA' | 'userB') => {
    setIsLoading(true);
    setErrorMsg(null);
    const testEmail = target === 'userA' ? 'alex.rivera@vchat.test' : 'jordan.lee@vchat.test';
    const testPass = 'VchatPass2026!';
    const testName = target === 'userA' ? 'Alex Rivera' : 'Jordan Lee';
    const testUser = target === 'userA' ? 'alex_rivera' : 'jordan_lee';
    const testPhoto =
      target === 'userA'
        ? 'https://lh3.googleusercontent.com/aida-public/AB6AXuDEEn0wOXHoTVZ8NVMgBbshd2PIpJD1bKFOmK2JfETKl07UJqY1Alaia1_MGjyEq-XXj6iyJrPU4M4f40u63w9Q_1DQPaB6xOzQXcdwxr_QNJ1ouDtHh7x4z_mUTilbXFeq7Lu4hTcCAQlGXgccjcKb1iqE10P28Jo8gQ7PIj3Gb4ErvCauVR38xMgc5mLJeoJV7UBcr4xmoU4yacVwNNAIr6tCJMf8pDVMCVDGog8b'
        : 'https://lh3.googleusercontent.com/aida-public/AB6AXuBccHs75S8w_0EcCl3YJUkaqtGmJGR7L0bycQEc8jxmA2C1nbpcc7lFIYdoy0Gvqwdbdqy6GhozvuSZcOTvva_QxvevGBVcM0wWDrrXSiollcRqtl9PaZWldC_KnE1B0vFzYmVfJhiof-09T8qiarTgbmgv5QF1FltkRnlTJoWUKAuSgNVP4ASt-VwplL__iIaShArOFTHKfdjq6LSQ_6Xk-KTOcFmPWXYaA932vvSf';

    try {
      // Attempt login
      const u = await loginWithEmail(testEmail, testPass);
      onSuccess(u);
    } catch {
      // Register in Firebase if not existing
      try {
        const u = await registerUser({
          fullName: testName,
          username: testUser,
          email: testEmail,
          password: testPass,
          profilePhotoUrl: testPhoto,
          bio: target === 'userA' ? 'Product Lead • Online' : 'UX Design Lead • Online',
        });
        onSuccess(u);
      } catch (regErr) {
        setErrorMsg(regErr instanceof Error ? regErr.message : 'Real Firebase authentication failed.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-surface-container-lowest max-w-md w-full rounded-3xl shadow-2xl border border-surface-container-high/80 p-6 my-8 animate-scaleUp">
        {/* Logo & Title */}
        <div className="flex flex-col items-center text-center mb-6">
          <img
            alt="V-CHAT"
            className="h-10 w-auto mb-2"
            src="https://lh3.googleusercontent.com/aida/AEtjO1XJLq4eXvG5vN8KHZd8xZ6dRZi7A-D3ncF4PMw4GL-yv5GnaLw0xk6uezSqrnz-nawi-4oPD-vEVC53kVBNdUuW4qjOjqvHvki2VQn14h_6wWXGpVpTmgpRv9SNkDlxldU0MhgCfAPn1WdQG0PyPtyshJjzbPr76A6Dm9Cj1JBv9A0AkdO2EGz0nrzlDAu8VT_pzviQVGncf-aERFJefNVwV8uepY8vXqZIMt7ir5YYvw"
          />
          <h2 className="text-xl font-bold text-on-surface">
            {mode === 'login'
              ? 'Welcome back to V-CHAT'
              : mode === 'register'
              ? 'Create your V-CHAT Account'
              : 'Reset your Password'}
          </h2>
          <p className="text-xs text-on-surface-variant mt-0.5">
            {mode === 'login'
              ? 'Multi-user real-time messaging powered by Firebase.'
              : mode === 'register'
              ? 'Enter your profile details to register.'
              : 'Enter your email to receive recovery instructions.'}
          </p>
        </div>

        {/* Tab switchers */}
        {mode !== 'forgot' && (
          <div className="flex bg-surface-container rounded-2xl p-1 mb-5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                mode === 'login'
                  ? 'bg-surface-container-lowest text-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                mode === 'register'
                  ? 'bg-surface-container-lowest text-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              Register
            </button>
          </div>
        )}

        {/* Feedback Alerts */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-2xl bg-error-container/30 border border-error/30 text-error text-xs flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">error</span>
            <span className="flex-1">{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 rounded-2xl bg-tertiary-fixed-dim/20 border border-tertiary-fixed-dim text-tertiary text-xs flex items-center gap-2">
            <span className="material-symbols-outlined text-[18px]">check_circle</span>
            <span className="flex-1">{successMsg}</span>
          </div>
        )}

        {/* --- 1. LOGIN FORM --- */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="flex flex-col gap-3.5">
            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-surface-container-high bg-surface-container-lowest text-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-on-surface">Password</label>
                <button
                  type="button"
                  onClick={() => setMode('forgot')}
                  className="text-xs text-primary font-semibold hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl border border-surface-container-high bg-surface-container-lowest text-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-primary-container to-secondary text-white font-semibold text-sm shadow-md hover:opacity-95 transition-all flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 mt-1 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Signing In...</span>
                </>
              ) : (
                <span>Sign In</span>
              )}
            </button>

            <div className="relative my-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-surface-container" />
              </div>
              <div className="relative flex justify-center text-xs text-on-surface-variant bg-surface-container-lowest px-2">
                Or continue with
              </div>
            </div>

            {/* Google sign-in */}
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl border border-surface-container-high hover:bg-surface-container-low transition-colors text-xs font-semibold text-on-surface flex items-center justify-center gap-2.5 active:scale-98"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Google Account</span>
            </button>

            {/* Quick Testing Section for Scenarios (Real Firebase Auth) */}
            <div className="mt-3 pt-3 border-t border-surface-container">
              <span className="text-[11px] font-bold text-outline uppercase tracking-wider block mb-1 text-center">
                Firebase Real Account Switcher
              </span>
              <p className="text-[10px] text-on-surface-variant text-center mb-2">
                Click below to instantly authenticate User A or User B against real Firebase Auth:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => quickAuthRealUser('userA')}
                  disabled={isLoading}
                  className="py-2 px-3 rounded-xl bg-primary/10 hover:bg-primary/20 text-primary text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span className="material-symbols-outlined text-[16px]">person</span>
                  <span>User A: Alex</span>
                </button>
                <button
                  type="button"
                  onClick={() => quickAuthRealUser('userB')}
                  disabled={isLoading}
                  className="py-2 px-3 rounded-xl bg-secondary/10 hover:bg-secondary/20 text-secondary text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span className="material-symbols-outlined text-[16px]">person</span>
                  <span>User B: Jordan</span>
                </button>
              </div>
            </div>
          </form>
        )}

        {/* --- 2. REGISTRATION FORM --- */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="flex flex-col gap-3 max-h-[60vh] overflow-y-auto px-1">
            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Alex Rivera"
                className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-on-surface">Unique Username *</label>
                {usernameStatus === 'checking' && (
                  <span className="text-[10px] text-outline">Checking availability...</span>
                )}
                {usernameStatus === 'available' && (
                  <span className="text-[10px] text-tertiary font-bold">✓ Username Available</span>
                )}
                {usernameStatus === 'taken' && (
                  <span className="text-[10px] text-error font-bold">✕ Username Taken</span>
                )}
              </div>
              <div className="relative">
                <span className="absolute left-3 top-2 text-outline text-xs">@</span>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => handleCheckUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  placeholder="unique_username"
                  className="w-full pl-7 pr-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="col-span-1">
                <label className="block text-xs font-semibold text-on-surface mb-1">Code</label>
                <input
                  type="text"
                  value={countryCode}
                  onChange={(e) => setCountryCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-on-surface mb-1">Mobile Number</label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="555-0199"
                  className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-on-surface mb-1">Password *</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min 6 chars"
                  className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-on-surface mb-1">Confirm *</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat"
                  className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">Optional Bio</label>
              <input
                type="text"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="e.g. Mobile Developer • Tech Enthusiast"
                className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
              />
            </div>

            <label className="flex items-center gap-2 mt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={termsAccepted}
                onChange={(e) => setTermsAccepted(e.target.checked)}
                className="rounded border-outline text-primary focus:ring-primary"
              />
              <span className="text-[11px] text-on-surface-variant">
                I agree to the V-CHAT Terms of Service and Privacy Policy.
              </span>
            </label>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-primary-container to-secondary text-white font-semibold text-sm shadow-md hover:opacity-95 transition-all flex items-center justify-center gap-2 mt-2 disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Registering Account...</span>
                </>
              ) : (
                <span>Complete Registration</span>
              )}
            </button>
          </form>
        )}

        {/* --- 3. FORGOT PASSWORD FORM --- */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="flex flex-col gap-3">
            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">
                Account Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2.5 rounded-xl border border-surface-container-high bg-surface-container-lowest text-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-primary text-white font-semibold text-sm shadow-md hover:opacity-95 transition-all flex items-center justify-center gap-2"
            >
              {isLoading ? 'Sending...' : 'Send Password Reset Email'}
            </button>

            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className="w-full py-2 text-xs font-semibold text-on-surface-variant hover:text-on-surface text-center"
            >
              Back to Sign In
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
