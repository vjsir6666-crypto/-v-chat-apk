import React, { useState } from 'react';
import { submitReport } from '../firebase/reportService';

interface ReportModalProps {
  isOpen: boolean;
  reporterId: string;
  targetType: 'user' | 'message' | 'group';
  targetId: string;
  targetName?: string;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  reporterId,
  targetType,
  targetId,
  targetName,
  onClose,
}) => {
  const [reason, setReason] = useState('Spam or Scam');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDone, setIsDone] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await submitReport(reporterId, targetType, targetId, reason, details);
      setIsDone(true);
      setTimeout(() => {
        setIsDone(false);
        onClose();
      }, 1500);
    } catch {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-surface-container-lowest max-w-sm w-full rounded-3xl shadow-2xl p-6 border border-surface-container-high animate-scaleUp">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-error">
            <span className="material-symbols-outlined text-[24px]">report</span>
            <h3 className="font-bold text-base">Report {targetType}</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant"
          >
            <span className="material-symbols-outlined text-[16px]">close</span>
          </button>
        </div>

        {isDone ? (
          <div className="py-8 text-center flex flex-col items-center gap-2">
            <span className="material-symbols-outlined text-tertiary text-[40px]">check_circle</span>
            <p className="text-sm font-bold text-on-surface">Report Submitted</p>
            <p className="text-xs text-on-surface-variant">Thank you for keeping V-CHAT safe.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-3 text-xs">
            <p className="text-on-surface-variant">
              Reporting: <span className="font-semibold text-on-surface">{targetName || targetId}</span>
            </p>

            <div>
              <label className="font-semibold text-on-surface block mb-1">Select a Reason</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
              >
                <option value="Spam or Scam">Spam or Scam</option>
                <option value="Harassment or Hate">Harassment or Hate</option>
                <option value="Inappropriate Content">Inappropriate Content</option>
                <option value="Impersonation">Impersonation</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-on-surface block mb-1">Additional details (optional)</label>
              <textarea
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe what occurred..."
                className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 rounded-xl bg-error text-white font-semibold text-xs shadow-md mt-2 flex items-center justify-center gap-2"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Report'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
