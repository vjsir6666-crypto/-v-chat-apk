import React, { useState } from 'react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  const [lastSeen, setLastSeen] = useState<'everyone' | 'contacts' | 'nobody'>('everyone');
  const [onlineStatus, setOnlineStatus] = useState<'everyone' | 'contacts' | 'nobody'>('everyone');
  const [readReceipts, setReadReceipts] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-surface-container-lowest max-w-md w-full rounded-3xl shadow-2xl p-6 border border-surface-container-high animate-scaleUp">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[24px]">security</span>
            <h3 className="font-bold text-lg text-on-surface">Privacy & Security</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        <div className="flex flex-col gap-4 text-xs">
          <div>
            <label className="font-semibold text-on-surface block mb-1">Who can see my Last Seen</label>
            <select
              value={lastSeen}
              onChange={(e) => setLastSeen(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
            >
              <option value="everyone">Everyone</option>
              <option value="contacts">My Contacts</option>
              <option value="nobody">Nobody</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-on-surface block mb-1">Who can see when I am Online</label>
            <select
              value={onlineStatus}
              onChange={(e) => setOnlineStatus(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none"
            >
              <option value="everyone">Everyone</option>
              <option value="contacts">My Contacts</option>
              <option value="nobody">Nobody</option>
            </select>
          </div>

          <label className="flex items-center justify-between py-2 border-t border-surface-container">
            <div>
              <span className="font-semibold text-on-surface block">Read Receipts</span>
              <span className="text-[10px] text-on-surface-variant">
                If turned off, you won't send or see read receipts (blue double ticks).
              </span>
            </div>
            <input
              type="checkbox"
              checked={readReceipts}
              onChange={(e) => setReadReceipts(e.target.checked)}
              className="rounded text-primary focus:ring-primary h-4 w-4"
            />
          </label>

          <div className="p-3 bg-surface-container-low rounded-2xl flex items-center gap-2.5">
            <span className="material-symbols-outlined text-tertiary text-[20px]">lock</span>
            <span className="text-[11px] text-on-surface-variant">
              All messages, media attachments, and voice calls in V-CHAT are protected with encrypted transmission.
            </span>
          </div>

          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-primary text-white font-semibold text-xs shadow-md mt-2"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
