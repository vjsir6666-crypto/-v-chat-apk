import React, { useState, useRef, useEffect } from 'react';
import { VChatMessage, VChatUser } from '../types';

interface MessageItemProps {
  message: VChatMessage;
  isCurrentUser: boolean;
  senderUser?: VChatUser | null;
  onImageClick?: (url: string, fileName?: string) => void;
  onReply?: (msg: VChatMessage) => void;
  onForward?: (msg: VChatMessage) => void;
  onReaction?: (messageId: string, emoji: string) => void;
  onDeleteForMe?: (messageId: string) => void;
  onDeleteForEveryone?: (messageId: string) => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  isCurrentUser,
  senderUser,
  onImageClick,
  onReply,
  onForward,
  onReaction,
  onDeleteForMe,
  onDeleteForEveryone,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [showMenu, setShowMenu] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const formattedTime = new Date(message.sentAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  const toggleAudio = () => {
    if (!message.mediaUrl) return;
    if (!audioRef.current) {
      audioRef.current = new Audio(message.mediaUrl);
      audioRef.current.ontimeupdate = () => {
        if (audioRef.current && audioRef.current.duration) {
          setAudioProgress((audioRef.current.currentTime / audioRef.current.duration) * 100);
        }
      };
      audioRef.current.onended = () => {
        setIsPlayingAudio(false);
        setAudioProgress(0);
      };
    }

    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioRef.current.play().catch(console.error);
      setIsPlayingAudio(true);
    }
  };

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const availableReactions = ['❤️', '👍', '😂', '😮', '😢', '🙏'];

  if (message.deletedForEveryone) {
    return (
      <div className={`flex items-end ${isCurrentUser ? 'justify-end' : 'justify-start'} w-full my-1`}>
        <div className="bg-surface-container-high/60 text-outline px-3 py-1.5 rounded-xl text-xs italic flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[14px]">block</span>
          <span>This message was deleted</span>
        </div>
      </div>
    );
  }

  return (
    <div className={`group relative flex items-end gap-2 max-w-[88%] ${isCurrentUser ? 'ml-auto justify-end' : 'mr-auto justify-start'} my-1`}>
      {/* Incoming Avatar */}
      {!isCurrentUser && (
        <img
          className="w-7 h-7 rounded-full object-cover flex-shrink-0 mb-1 ring-1 ring-black/5"
          alt={senderUser?.fullName || 'User'}
          src={
            senderUser?.profilePhotoUrl ||
            'https://lh3.googleusercontent.com/aida-public/AB6AXuCIyMbfkGqu2gXLP8j4Sp7NYCyk_nu9orDMeJ1VUdIhVpWzx89m2kIbIavAyrrD1frzfJi6sv2Jv5k96hVYLoaplhBiXcrR3L0GnDFBS8ADD7a4kMmum9WRB3lDdGictdhS5KMTGWvRT6iIFjNUR3wFj8YOVNDZ1rNK5rmzfxTtSfRg_QvbhDK2iSHQH9UGsmnczPwY5yv_L8VejUmDf3xFUgYrH_93q_6n9DKOwfry'
          }
        />
      )}

      {/* Bubble Container */}
      <div className="flex flex-col items-end gap-1 max-w-full">
        <div
          className={`relative p-3.5 rounded-2xl shadow-sm transition-all ${
            isCurrentUser
              ? 'bg-gradient-to-br from-primary-container to-secondary text-on-primary rounded-br-sm shadow-md'
              : 'bg-surface-container-lowest text-on-surface rounded-bl-sm border border-surface-container/60'
          }`}
        >
          {/* Reply Quote Banner */}
          {message.replyTo && (
            <div
              className={`mb-2 p-2 rounded-lg text-xs border-l-2 flex flex-col ${
                isCurrentUser
                  ? 'bg-black/15 border-white/80 text-white/90'
                  : 'bg-surface-container border-primary text-on-surface-variant'
              }`}
            >
              <span className="font-semibold">{message.replyTo.senderName}</span>
              <span className="truncate">{message.replyTo.messageText || message.replyTo.messageType}</span>
            </div>
          )}

          {/* Forwarded Tag */}
          {message.forwarded && (
            <div className="flex items-center gap-1 text-[11px] opacity-75 mb-1 italic">
              <span className="material-symbols-outlined text-[13px]">forward</span>
              <span>Forwarded</span>
            </div>
          )}

          {/* 1. TEXT MESSAGE */}
          {message.messageType === 'text' && (
            <p
              className={`font-normal leading-relaxed break-words whitespace-pre-wrap ${
                message.messageText.length <= 12 &&
                /\p{Extended_Pictographic}/u.test(message.messageText) &&
                !/[a-zA-Z0-9]/.test(message.messageText)
                  ? 'text-3xl py-1 tracking-wider'
                  : 'text-sm md:text-base'
              }`}
            >
              {message.messageText}
            </p>
          )}

          {/* 2. IMAGE MESSAGE */}
          {message.messageType === 'image' && message.mediaUrl && (
            <div className="flex flex-col gap-1.5 -m-1">
              <div
                className="relative rounded-xl overflow-hidden cursor-pointer max-w-[270px] shadow-xs hover:opacity-95 transition-opacity"
                onClick={() => onImageClick?.(message.mediaUrl!, message.fileName)}
              >
                <img
                  src={message.mediaUrl}
                  alt={message.fileName || 'Shared image'}
                  className="w-full h-44 object-cover"
                  loading="lazy"
                />
                <div className="absolute bottom-2 right-2 bg-inverse-surface/75 backdrop-blur-md px-2 py-0.5 rounded-full flex items-center gap-1 text-inverse-on-surface text-[11px]">
                  <span className="material-symbols-outlined text-[13px]">image</span>
                  <span>{message.fileName || 'View Photo'}</span>
                </div>
              </div>
              {message.messageText && (
                <p className="px-1 text-sm font-normal pt-1">{message.messageText}</p>
              )}
            </div>
          )}

          {/* 3. VIDEO MESSAGE */}
          {message.messageType === 'video' && message.mediaUrl && (
            <div className="flex flex-col gap-1 -m-1 max-w-[280px]">
              <video
                src={message.mediaUrl}
                controls
                className="w-full rounded-xl max-h-48 bg-black object-contain"
              />
              {message.messageText && (
                <p className="px-1 text-sm pt-1">{message.messageText}</p>
              )}
            </div>
          )}

          {/* 4. VOICE / AUDIO MESSAGE */}
          {(message.messageType === 'voice' || message.messageType === 'audio') && (
            <div className="flex items-center gap-3 min-w-[220px] max-w-[280px] py-0.5">
              <button
                onClick={toggleAudio}
                aria-label={isPlayingAudio ? 'Pause Voice Note' : 'Play Voice Note'}
                className={`w-10 h-10 rounded-full flex items-center justify-center shadow-md flex-shrink-0 active:scale-95 transition-transform ${
                  isCurrentUser
                    ? 'bg-surface-container-lowest text-primary'
                    : 'bg-primary text-on-primary'
                }`}
              >
                <span className="material-symbols-outlined text-[22px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  {isPlayingAudio ? 'pause' : 'play_arrow'}
                </span>
              </button>

              <div className="flex-1 flex flex-col gap-1.5 min-w-0">
                {/* Audio Waveform visualization */}
                <div className="flex items-center gap-0.5 h-6 w-full cursor-pointer" onClick={toggleAudio}>
                  {[12, 20, 8, 24, 16, 20, 12, 24, 14, 8, 20, 12, 24, 16, 8, 20, 12, 6].map((h, i) => {
                    const isPlayed = (i / 18) * 100 <= audioProgress;
                    return (
                      <span
                        key={i}
                        style={{ height: `${h}px` }}
                        className={`w-1 rounded-full transition-all duration-150 ${
                          isPlayed
                            ? isCurrentUser
                              ? 'bg-surface-container-lowest'
                              : 'bg-primary'
                            : isCurrentUser
                            ? 'bg-white/40'
                            : 'bg-outline-variant'
                        } ${isPlayingAudio ? 'animate-pulse' : ''}`}
                      />
                    );
                  })}
                </div>

                <div className="flex items-center justify-between text-[11px] opacity-80">
                  <span>{message.duration ? `${Math.floor(message.duration / 60)}:${(message.duration % 60).toString().padStart(2, '0')}` : '0:34'}</span>
                  <span>{formattedTime}</span>
                </div>
              </div>
            </div>
          )}

          {/* 5. DOCUMENT MESSAGE */}
          {message.messageType === 'document' && (
            <div className="flex items-center gap-3 p-1 min-w-[200px]">
              <div className="w-10 h-10 rounded-xl bg-tertiary-fixed-dim/30 text-tertiary-container flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-[24px]">description</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{message.fileName || 'Document'}</p>
                <p className="text-xs opacity-75">
                  {message.fileSize ? `${(message.fileSize / 1024).toFixed(1)} KB` : 'PDF Document'}
                </p>
              </div>
              {message.mediaUrl && (
                <a
                  href={message.mediaUrl}
                  download={message.fileName || 'download'}
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center hover:bg-surface-container-high transition-colors"
                >
                  <span className="material-symbols-outlined text-[18px]">download</span>
                </a>
              )}
            </div>
          )}

          {/* 6. LOCATION MESSAGE */}
          {message.messageType === 'location' && message.locationData && (
            <div className="flex flex-col gap-1 -m-1 max-w-[260px]">
              <div className="h-32 bg-surface-container-high rounded-xl flex flex-col items-center justify-center p-3 text-center relative overflow-hidden">
                <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-1">
                  <span className="material-symbols-outlined text-[24px]">location_on</span>
                </div>
                <span className="font-semibold text-xs text-on-surface truncate">
                  {message.locationData.name || 'Shared Location'}
                </span>
                <span className="text-[10px] text-on-surface-variant truncate">
                  {message.locationData.latitude.toFixed(4)}, {message.locationData.longitude.toFixed(4)}
                </span>
              </div>
              <a
                href={`https://maps.google.com/?q=${message.locationData.latitude},${message.locationData.longitude}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-center py-1 font-semibold underline text-primary"
              >
                Open in Google Maps
              </a>
            </div>
          )}

          {/* 7. CONTACT MESSAGE */}
          {message.messageType === 'contact' && message.contactData && (
            <div className="flex items-center gap-3 p-1 min-w-[220px]">
              <div className="w-10 h-10 rounded-full bg-primary-fixed text-primary flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-[22px]">person</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{message.contactData.name}</p>
                <p className="text-xs opacity-80 truncate">{message.contactData.phoneNumber}</p>
              </div>
              <a
                href={`tel:${message.contactData.phoneNumber}`}
                className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-primary"
              >
                <span className="material-symbols-outlined text-[18px]">call</span>
              </a>
            </div>
          )}

          {/* Message Status & Timestamp */}
          {message.messageType !== 'voice' && message.messageType !== 'audio' && (
            <div
              className={`flex items-center justify-end gap-1 mt-1 text-[11px] ${
                isCurrentUser ? 'text-surface-container-highest' : 'text-on-surface-variant'
              }`}
            >
              <span className="opacity-80">{formattedTime}</span>
              {isCurrentUser && (
                message.status === 'sending' ? (
                  <span className="material-symbols-outlined text-[13px] animate-spin opacity-80">
                    progress_activity
                  </span>
                ) : (
                  <span
                    className={`material-symbols-outlined text-[15px] ${
                      message.status === 'read' ? 'text-tertiary-fixed-dim' : 'opacity-80'
                    }`}
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    {message.status === 'read' || message.status === 'delivered' ? 'done_all' : 'check'}
                  </span>
                )
              )}
            </div>
          )}
        </div>

        {/* Emoji Reactions Pill */}
        {message.reactions && Object.keys(message.reactions).length > 0 && (
          <div className="-mt-3 mr-2 bg-surface-container-lowest rounded-full px-2 py-0.5 shadow-sm border border-surface-container flex items-center gap-1.5 z-10 cursor-pointer">
            {Object.entries(message.reactions).map(([emoji, userIds]) => (
              <span
                key={emoji}
                onClick={() => onReaction?.(message.messageId, emoji)}
                className="text-xs flex items-center gap-0.5 hover:scale-110 transition-transform"
              >
                <span>{emoji}</span>
                <span className="text-[11px] text-on-surface font-semibold">{userIds.length}</span>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Quick Action Button (Hover/Touch) */}
      <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5 relative mb-2">
        <button
          onClick={() => setShowReactionPicker(!showReactionPicker)}
          title="React"
          className="w-7 h-7 rounded-full bg-surface-container text-on-surface-variant hover:text-primary flex items-center justify-center shadow-xs"
        >
          <span className="material-symbols-outlined text-[16px]">add_reaction</span>
        </button>

        <button
          onClick={() => setShowMenu(!showMenu)}
          title="More options"
          className="w-7 h-7 rounded-full bg-surface-container text-on-surface-variant hover:text-primary flex items-center justify-center shadow-xs"
        >
          <span className="material-symbols-outlined text-[16px]">more_vert</span>
        </button>

        {/* Reaction Picker Overlay */}
        {showReactionPicker && (
          <div className="absolute bottom-9 right-0 bg-surface-container-lowest rounded-full shadow-lg border border-surface-container px-2 py-1 flex items-center gap-1.5 z-30 animate-fadeIn">
            {availableReactions.map((emoji) => (
              <button
                key={emoji}
                onClick={() => {
                  onReaction?.(message.messageId, emoji);
                  setShowReactionPicker(false);
                }}
                className="hover:scale-125 transition-transform text-base p-1"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        {/* Context Menu Overlay */}
        {showMenu && (
          <>
            <div className="fixed inset-0 z-30" onClick={() => setShowMenu(false)} />
            <div className="absolute bottom-9 right-0 bg-surface-container-lowest rounded-2xl shadow-xl border border-surface-container-high py-1.5 w-40 z-40 text-xs">
              <button
                onClick={() => {
                  setShowMenu(false);
                  onReply?.(message);
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-on-surface hover:bg-surface-container"
              >
                <span className="material-symbols-outlined text-[16px]">reply</span>
                <span>Reply</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onForward?.(message);
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-on-surface hover:bg-surface-container"
              >
                <span className="material-symbols-outlined text-[16px]">forward</span>
                <span>Forward</span>
              </button>

              {message.messageText && (
                <button
                  onClick={() => {
                    setShowMenu(false);
                    navigator.clipboard.writeText(message.messageText);
                  }}
                  className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-on-surface hover:bg-surface-container"
                >
                  <span className="material-symbols-outlined text-[16px]">content_copy</span>
                  <span>Copy Text</span>
                </button>
              )}

              <button
                onClick={() => {
                  setShowMenu(false);
                  onDeleteForMe?.(message.messageId);
                }}
                className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-on-surface hover:bg-surface-container"
              >
                <span className="material-symbols-outlined text-[16px]">delete</span>
                <span>Delete for me</span>
              </button>

              {isCurrentUser && (
                <button
                  onClick={() => {
                    setShowMenu(false);
                    onDeleteForEveryone?.(message.messageId);
                  }}
                  className="w-full px-3 py-1.5 text-left flex items-center gap-2 text-error hover:bg-error-container/20"
                >
                  <span className="material-symbols-outlined text-[16px]">delete_forever</span>
                  <span>Delete for everyone</span>
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
