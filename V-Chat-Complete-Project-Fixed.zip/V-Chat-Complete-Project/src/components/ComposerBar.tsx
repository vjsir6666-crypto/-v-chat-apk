import React, { useState, useRef } from 'react';
import { ReplyPreview } from '../types';

interface ComposerBarProps {
  onSendMessage: (text: string) => Promise<boolean | void> | boolean | void;
  onSendVoiceNote: (audioBlob: Blob, durationSeconds: number) => void;
  onToggleDrawer: () => void;
  onQuickCamera: () => void;
  replyTo: ReplyPreview | null;
  onCancelReply: () => void;
  onTyping: (isTyping: boolean) => void;
  disabled?: boolean;
}

export const ComposerBar: React.FC<ComposerBarProps> = ({
  onSendMessage,
  onSendVoiceNote,
  onToggleDrawer,
  onQuickCamera,
  replyTo,
  onCancelReply,
  onTyping,
  disabled = false,
}) => {
  const [text, setText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const typingTimerRef = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setText(val);

    // Notify typing presence
    onTyping(true);
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = window.setTimeout(() => {
      onTyping(false);
    }, 2000);
  };

  const handleSend = async () => {
    const trimmed = text.trim();
    if (!trimmed || disabled || isSending) return;
    setIsSending(true);
    try {
      const result = await onSendMessage(trimmed);
      if (result === false) return;
      setText('');
      onTyping(false);
      if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
      inputRef.current?.focus();
    } catch (error) {
      console.error('Composer send failed:', error);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Voice Recording handlers
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordSeconds(0);

      recordTimerRef.current = window.setInterval(() => {
        setRecordSeconds((sec) => sec + 1);
      }, 1000);
    } catch (err) {
      console.error('Microphone access error:', err);
      alert('Microphone permission is required to record voice notes.');
    }
  };

  const stopAndSendRecording = () => {
    if (!mediaRecorderRef.current) return;
    const duration = recordSeconds;

    mediaRecorderRef.current.onstop = () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      mediaRecorderRef.current?.stream.getTracks().forEach((track) => track.stop());
      onSendVoiceNote(audioBlob, duration);
      setIsRecording(false);
      setRecordSeconds(0);
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    };

    mediaRecorderRef.current.stop();
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.onstop = null;
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    }
    setIsRecording(false);
    setRecordSeconds(0);
    if (recordTimerRef.current) clearInterval(recordTimerRef.current);
  };

  const emojiCategories = [
    {
      category: 'Smileys & People',
      emojis: ['😊', '😂', '🤣', '❤️', '😍', '😘', '😎', '🥳', '🤔', '🙌', '👍', '🙏', '🔥', '✨', '👏', '💯'],
    },
    {
      category: 'Gestures & Reactions',
      emojis: ['👋', '✌️', '👌', '🤝', '💪', '👀', '🎉', '🚀', '⭐', '💡', '🏆', '🎯', '🍕', '☕', '🌟', '💬'],
    },
    {
      category: 'Expressions',
      emojis: ['😇', '🤩', '😜', '🤗', '😴', '🙄', '🥺', '😭', '🤯', '🥳', '🤐', '🤫', '💀', '👽', '🤖', '⚡'],
    },
  ];

  const handleSelectEmoji = (em: string) => {
    setText((prev) => prev + em);
    onTyping(true);
    inputRef.current?.focus();
  };

  const hasText = text.trim().length > 0;

  return (
    <div className="fixed bottom-0 inset-x-0 bg-surface/95 backdrop-blur-xl px-4 py-2 z-30 pb-safe shadow-[0_-4px_16px_rgba(0,0,0,0.04)] border-t border-surface-container">
      <div className="max-w-md mx-auto flex flex-col gap-1.5 relative">
        {/* Reply Quote Banner */}
        {replyTo && (
          <div className="flex items-center justify-between bg-surface-container-lowest px-3 py-1.5 rounded-xl border-l-4 border-primary shadow-xs">
            <div className="flex flex-col min-w-0 pr-2">
              <span className="text-xs font-semibold text-primary truncate">
                Replying to {replyTo.senderName}
              </span>
              <span className="text-xs text-on-surface-variant truncate">
                {replyTo.messageText || replyTo.messageType}
              </span>
            </div>
            <button
              onClick={onCancelReply}
              className="w-6 h-6 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>
        )}

        {/* Multi-Emoji Picker Popover */}
        {showEmojiPicker && (
          <>
            <div
              className="fixed inset-0 z-20"
              onClick={() => setShowEmojiPicker(false)}
            />
            <div className="absolute bottom-16 inset-x-0 bg-surface-container-lowest rounded-3xl p-3 shadow-2xl border border-surface-container-high z-30 animate-scaleUp max-h-64 overflow-y-auto">
              <div className="flex items-center justify-between pb-2 border-b border-surface-container mb-2">
                <span className="text-xs font-bold text-on-surface">Select Emojis (Click multiple)</span>
                <button
                  type="button"
                  onClick={() => setShowEmojiPicker(false)}
                  className="px-2.5 py-0.5 rounded-full bg-primary text-white text-[11px] font-semibold hover:bg-primary-container"
                >
                  Done
                </button>
              </div>

              {emojiCategories.map((cat) => (
                <div key={cat.category} className="mb-2">
                  <span className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider block mb-1">
                    {cat.category}
                  </span>
                  <div className="grid grid-cols-8 gap-1">
                    {cat.emojis.map((em) => (
                      <button
                        key={em}
                        type="button"
                        onClick={() => handleSelectEmoji(em)}
                        className="text-2xl p-1 hover:bg-surface-container rounded-xl transition-transform hover:scale-125 active:scale-95"
                      >
                        {em}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Recording active banner */}
        {isRecording ? (
          <div className="flex items-center justify-between bg-surface-container-lowest rounded-full px-4 py-2 shadow-md border border-error/30 animate-pulse">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-error animate-ping" />
              <span className="text-sm font-semibold text-error">
                Recording {Math.floor(recordSeconds / 60)}:{(recordSeconds % 60).toString().padStart(2, '0')}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={cancelRecording}
                className="px-3 py-1 text-xs font-semibold text-on-surface-variant hover:text-error"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={stopAndSendRecording}
                className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-container to-secondary text-on-primary flex items-center justify-center shadow-md active:scale-90"
              >
                <span className="material-symbols-outlined text-[20px]">send</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            {/* Attachment & Emoji buttons */}
            <div className="flex items-center gap-0.5">
              <button
                type="button"
                onClick={onToggleDrawer}
                aria-label="Attach File"
                title="Attach Files / Media"
                disabled={disabled}
                className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface-variant hover:bg-surface-container hover:text-primary transition-colors active:scale-95"
              >
                <span className="material-symbols-outlined text-[22px]">attach_file</span>
              </button>

              <button
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                aria-label="Pick Emoji"
                title="Choose Emojis"
                disabled={disabled}
                className={`w-10 h-10 flex items-center justify-center rounded-full transition-colors active:scale-95 ${
                  showEmojiPicker
                    ? 'bg-primary/10 text-primary'
                    : 'text-on-surface-variant hover:bg-surface-container hover:text-primary'
                }`}
              >
                <span className="material-symbols-outlined text-[22px]">sentiment_satisfied</span>
              </button>
            </div>

            {/* Pill Input Field */}
            <div className="flex-1 flex items-center bg-surface-container-lowest rounded-full px-3 py-1.5 shadow-sm border border-surface-container-high/80 focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/15 transition-all">
              <input
                ref={inputRef}
                type="text"
                value={text}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                disabled={disabled}
                placeholder="Type a message..."
                className="w-full bg-transparent text-on-surface placeholder:text-outline focus:outline-none text-sm py-1 font-normal"
              />
              <button
                type="button"
                onClick={onQuickCamera}
                aria-label="Open Camera"
                title="Take Photo"
                disabled={disabled}
                className="w-8 h-8 flex items-center justify-center rounded-full text-on-surface-variant hover:text-primary transition-colors flex-shrink-0 active:scale-90"
              >
                <span className="material-symbols-outlined text-[20px]">photo_camera</span>
              </button>
            </div>

            {/* Clearly Visible Send Button + Optional Mic button */}
            <div className="flex items-center gap-1 flex-shrink-0">
              {!hasText && (
                <button
                  type="button"
                  onClick={startRecording}
                  aria-label="Record Voice Note"
                  title="Record voice note"
                  disabled={disabled}
                  className="w-10 h-10 rounded-full bg-surface-container text-on-surface-variant hover:text-secondary hover:bg-surface-container-high flex items-center justify-center transition-all active:scale-90"
                >
                  <span className="material-symbols-outlined text-[20px]">mic</span>
                </button>
              )}

              {/* DEDICATED VISIBLE SEND BUTTON */}
              <button
                type="button"
                onClick={handleSend}
                disabled={disabled || !hasText || isSending}
                aria-label="Send Message"
                title={isSending ? 'Sending message' : hasText ? 'Send message' : 'Type a message to send'}
                className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
                  hasText
                    ? 'bg-gradient-to-br from-primary-container to-secondary text-white shadow-[0_8px_20px_-3px_rgba(29,78,216,0.45)] hover:shadow-lg active:scale-90 cursor-pointer'
                    : 'bg-surface-container text-outline opacity-40 cursor-not-allowed'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">{isSending ? "progress_activity" : "send"}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
