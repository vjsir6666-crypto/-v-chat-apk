import React from 'react';

interface AttachmentDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectGallery: () => void;
  onSelectCamera: () => void;
  onSelectDocument: () => void;
  onSelectAudio: () => void;
  onSelectLocation: () => void;
  onSelectContact: () => void;
}

export const AttachmentDrawer: React.FC<AttachmentDrawerProps> = ({
  isOpen,
  onClose,
  onSelectGallery,
  onSelectCamera,
  onSelectDocument,
  onSelectAudio,
  onSelectLocation,
  onSelectContact,
}) => {
  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/20 z-40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />
      <div className="fixed inset-x-0 bottom-24 mx-auto max-w-md px-4 z-40 transition-all transform duration-300 animate-slideUp">
        <div className="bg-surface-container-lowest/95 backdrop-blur-xl p-4 rounded-3xl shadow-2xl border border-surface-container-high/80">
          <div className="flex items-center justify-between mb-3 px-1">
            <span className="text-base text-on-surface font-bold">Share Content</span>
            <button
              onClick={onClose}
              aria-label="Close attachment drawer"
              className="w-7 h-7 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {/* 1. Gallery */}
            <button
              onClick={() => {
                onClose();
                onSelectGallery();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors gap-1.5 group active:scale-95"
            >
              <div className="w-11 h-11 rounded-full bg-primary/10 text-primary flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <span className="material-symbols-outlined text-[22px]">photo_library</span>
              </div>
              <span className="text-xs font-semibold text-on-surface">Gallery</span>
            </button>

            {/* 2. Camera */}
            <button
              onClick={() => {
                onClose();
                onSelectCamera();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors gap-1.5 group active:scale-95"
            >
              <div className="w-11 h-11 rounded-full bg-secondary-container/20 text-secondary flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <span className="material-symbols-outlined text-[22px]">photo_camera</span>
              </div>
              <span className="text-xs font-semibold text-on-surface">Camera</span>
            </button>

            {/* 3. Document */}
            <button
              onClick={() => {
                onClose();
                onSelectDocument();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors gap-1.5 group active:scale-95"
            >
              <div className="w-11 h-11 rounded-full bg-tertiary-fixed-dim/30 text-tertiary-container flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <span className="material-symbols-outlined text-[22px]">description</span>
              </div>
              <span className="text-xs font-semibold text-on-surface">Document</span>
            </button>

            {/* 4. Audio */}
            <button
              onClick={() => {
                onClose();
                onSelectAudio();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors gap-1.5 group active:scale-95"
            >
              <div className="w-11 h-11 rounded-full bg-secondary-fixed/50 text-on-secondary-fixed-variant flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <span className="material-symbols-outlined text-[22px]">headphones</span>
              </div>
              <span className="text-xs font-semibold text-on-surface">Audio</span>
            </button>

            {/* 5. Location */}
            <button
              onClick={() => {
                onClose();
                onSelectLocation();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors gap-1.5 group active:scale-95"
            >
              <div className="w-11 h-11 rounded-full bg-primary-fixed/60 text-primary flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <span className="material-symbols-outlined text-[22px]">location_on</span>
              </div>
              <span className="text-xs font-semibold text-on-surface">Location</span>
            </button>

            {/* 6. Contact */}
            <button
              onClick={() => {
                onClose();
                onSelectContact();
              }}
              className="flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors gap-1.5 group active:scale-95"
            >
              <div className="w-11 h-11 rounded-full bg-surface-container-highest text-on-surface-variant flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                <span className="material-symbols-outlined text-[22px]">person</span>
              </div>
              <span className="text-xs font-semibold text-on-surface">Contact</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
