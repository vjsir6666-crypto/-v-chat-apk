import React from 'react';
import { VChatUser } from '../types';

interface PeerStatusBarProps {
  peerUser: VChatUser | null;
  isTyping: boolean;
  onStartVoiceCall: () => void;
  onStartVideoCall: () => void;
  onViewProfile?: () => void;
  onBlockUser?: () => void;
  onReportUser?: () => void;
  onClearChat?: () => void;
}

export const PeerStatusBar: React.FC<PeerStatusBarProps> = ({
  peerUser,
  isTyping,
  onStartVoiceCall,
  onStartVideoCall,
  onViewProfile,
  onBlockUser,
  onReportUser,
  onClearChat,
}) => {
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  if (!peerUser) return null;

  const displayName = peerUser.fullName || peerUser.username || 'Chat User';
  const isOnline = peerUser.isOnline;

  return (
    <div className="w-full bg-surface-container-low shadow-sm border-b border-surface-container/60">
      <div className="max-w-4xl mx-auto px-4 py-2 flex items-center justify-between">
        {/* Left: Avatar + Name + Presence */}
        <div
          className="flex items-center gap-3 min-w-0 cursor-pointer"
          onClick={onViewProfile}
        >
          <div className="relative flex-shrink-0">
            <img
              className="w-10 h-10 rounded-full object-cover shadow-sm ring-1 ring-black/5"
              alt={displayName}
              src={
                peerUser.profilePhotoUrl ||
                'https://lh3.googleusercontent.com/aida-public/AB6AXuDEEn0wOXHoTVZ8NVMgBbshd2PIpJD1bKFOmK2JfETKl07UJqY1Alaia1_MGjyEq-XXj6iyJrPU4M4f40u63w9Q_1DQPaB6xOzQXcdwxr_QNJ1ouDtHh7x4z_mUTilbXFeq7Lu4hTcCAQlGXgccjcKb1iqE10P28Jo8gQ7PIj3Gb4ErvCauVR38xMgc5mLJeoJV7UBcr4xmoU4yacVwNNAIr6tCJMf8pDVMCVDGog8b'
              }
            />
            {isOnline && (
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-tertiary-fixed-dim ring-2 ring-surface"></span>
            )}
          </div>

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-base text-on-surface truncate">
                {displayName}
              </span>
              <span
                className="material-symbols-outlined text-[15px] text-primary"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                verified
              </span>
            </div>

            <div className="flex items-center gap-1">
              {isTyping ? (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                  <span className="text-xs text-primary font-medium truncate">typing...</span>
                </>
              ) : isOnline ? (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-tertiary-fixed-dim animate-pulse"></span>
                  <span className="text-xs text-on-tertiary-fixed-variant truncate">
                    {peerUser.bio || 'Online'}
                  </span>
                </>
              ) : (
                <span className="text-xs text-on-surface-variant truncate">
                  {peerUser.lastSeen
                    ? `Last seen ${new Date(peerUser.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                    : 'Offline'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right: Call & Options Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onStartVoiceCall}
            aria-label="Start Voice Call"
            title="Start Voice Call"
            className="w-9 h-9 flex items-center justify-center rounded-full bg-surface-container text-primary hover:bg-primary-fixed transition-all active:scale-95 shadow-xs"
          >
            <span className="material-symbols-outlined text-[20px]">call</span>
          </button>

          <button
            onClick={onStartVideoCall}
            aria-label="Start Video Call"
            title="Start Video Call"
            className="w-9 h-9 flex items-center justify-center rounded-full bg-surface-container text-primary hover:bg-primary-fixed transition-all active:scale-95 shadow-xs"
          >
            <span className="material-symbols-outlined text-[20px]">videocam</span>
          </button>

          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              aria-label="More Options"
              className="w-9 h-9 flex items-center justify-center rounded-full bg-surface-container text-on-surface-variant hover:bg-surface-variant transition-all active:scale-95 shadow-xs"
            >
              <span className="material-symbols-outlined text-[20px]">more_vert</span>
            </button>

            {dropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-30"
                  onClick={() => setDropdownOpen(false)}
                />
                <div className="absolute right-0 top-11 w-48 bg-surface-container-lowest rounded-2xl shadow-xl border border-surface-container-high py-2 z-40 text-sm">
                  {onViewProfile && (
                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        onViewProfile();
                      }}
                      className="w-full px-4 py-2 text-left flex items-center gap-2.5 text-on-surface hover:bg-surface-container"
                    >
                      <span className="material-symbols-outlined text-[18px]">account_box</span>
                      <span>View Profile</span>
                    </button>
                  )}

                  {onClearChat && (
                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        onClearChat();
                      }}
                      className="w-full px-4 py-2 text-left flex items-center gap-2.5 text-on-surface hover:bg-surface-container"
                    >
                      <span className="material-symbols-outlined text-[18px]">clear_all</span>
                      <span>Clear Chat</span>
                    </button>
                  )}

                  {onBlockUser && (
                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        onBlockUser();
                      }}
                      className="w-full px-4 py-2 text-left flex items-center gap-2.5 text-on-surface hover:bg-surface-container"
                    >
                      <span className="material-symbols-outlined text-[18px]">block</span>
                      <span>Block User</span>
                    </button>
                  )}

                  {onReportUser && (
                    <button
                      onClick={() => {
                        setDropdownOpen(false);
                        onReportUser();
                      }}
                      className="w-full px-4 py-2 text-left flex items-center gap-2.5 text-error hover:bg-error-container/20"
                    >
                      <span className="material-symbols-outlined text-[18px]">report</span>
                      <span>Report User</span>
                    </button>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
