import React, { useState } from 'react';
import { VChatRoom, VChatGroup, VChatUser } from '../types';

interface ConversationsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: VChatUser;
  chats: VChatRoom[];
  groups: VChatGroup[];
  allRegisteredUsers: VChatUser[];
  activeChatId: string | null;
  onSelectChat: (chat: VChatRoom) => void;
  onSelectGroup: (group: VChatGroup) => void;
  onStartChatWithUser: (user: VChatUser) => void;
  onNewGroupClick: () => void;
  initialTab?: 'chats' | 'users' | 'groups';
}

export const ConversationsDrawer: React.FC<ConversationsDrawerProps> = ({
  isOpen,
  onClose,
  currentUser,
  chats,
  groups,
  allRegisteredUsers,
  activeChatId,
  onSelectChat,
  onSelectGroup,
  onStartChatWithUser,
  onNewGroupClick,
  initialTab = 'chats',
}) => {
  const [activeTab, setActiveTab] = useState<'chats' | 'users' | 'groups'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredChats = chats.filter((c) => {
    if (!searchQuery) return true;
    const otherParticipantId = c.participants.find((p) => p !== currentUser.uid) || '';
    const otherDetails = c.participantDetails?.[otherParticipantId];
    return (
      otherDetails?.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      otherDetails?.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const filteredUsers = allRegisteredUsers.filter((u) => {
    // Never show current logged in user as their own contact
    if (u.uid === currentUser.uid) return false;
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      u.fullName?.toLowerCase().includes(q) ||
      u.username?.toLowerCase().includes(q) ||
      u.bio?.toLowerCase().includes(q)
    );
  });

  const filteredGroups = groups.filter((g) => {
    if (!searchQuery) return true;
    return (
      g.groupName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.description?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/40 backdrop-blur-xs" onClick={onClose} />

      {/* Drawer Container */}
      <div className="relative w-full max-w-sm bg-surface flex flex-col h-full shadow-2xl z-10 border-r border-surface-container animate-slideRight">
        {/* Header */}
        <div className="p-4 bg-surface-container-low border-b border-surface-container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              alt="V-CHAT"
              className="h-6 w-auto"
              src="https://lh3.googleusercontent.com/aida/AEtjO1XJLq4eXvG5vN8KHZd8xZ6dRZi7A-D3ncF4PMw4GL-yv5GnaLw0xk6uezSqrnz-nawi-4oPD-vEVC53kVBNdUuW4qjOjqvHvki2VQn14h_6wWXGpVpTmgpRv9SNkDlxldU0MhgCfAPn1WdQG0PyPtyshJjzbPr76A6Dm9Cj1JBv9A0AkdO2EGz0nrzlDAu8VT_pzviQVGncf-aERFJefNVwV8uepY8vXqZIMt7ir5YYvw"
            />
            <h2 className="font-bold text-lg text-on-surface">V-CHAT Hub</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Search bar */}
        <div className="p-3 bg-surface-container-low/60 border-b border-surface-container">
          <div className="flex items-center bg-surface-container-lowest rounded-full px-3 py-1.5 border border-surface-container-high shadow-xs">
            <span className="material-symbols-outlined text-[18px] text-outline mr-2">search</span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                activeTab === 'users'
                  ? 'Search by username or name...'
                  : activeTab === 'chats'
                  ? 'Search conversations...'
                  : 'Search groups...'
              }
              className="w-full bg-transparent text-xs text-on-surface focus:outline-none"
            />
            {searchQuery && (
              <button type="button" onClick={() => setSearchQuery('')} className="text-outline hover:text-on-surface">
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            )}
          </div>
        </div>

        {/* 3 Tabs: Chats, Users/Contacts, Groups */}
        <div className="flex border-b border-surface-container bg-surface-container-lowest">
          <button
            type="button"
            onClick={() => setActiveTab('chats')}
            className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'chats'
                ? 'border-primary text-primary'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">chat</span>
            <span>Chats ({chats.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('users')}
            className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'users'
                ? 'border-primary text-primary'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">group</span>
            <span>Users ({allRegisteredUsers.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('groups')}
            className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1 ${
              activeTab === 'groups'
                ? 'border-primary text-primary'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">groups</span>
            <span>Groups ({groups.length})</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto divide-y divide-surface-container/60 p-2">
          {/* TAB 1: ACTIVE CHATS */}
          {activeTab === 'chats' && (
            filteredChats.length === 0 ? (
              <div className="text-center py-12 px-4 text-on-surface-variant">
                <span className="material-symbols-outlined text-[44px] text-outline mb-2">forum</span>
                <p className="text-sm font-semibold">No active conversations</p>
                <p className="text-xs mt-1 text-outline">Click on the Users tab to find registered users and start chatting!</p>
                <button
                  type="button"
                  onClick={() => setActiveTab('users')}
                  className="mt-4 px-4 py-2 rounded-full bg-primary text-white text-xs font-semibold shadow-sm hover:bg-primary-container transition-colors inline-flex items-center gap-1.5"
                >
                  <span className="material-symbols-outlined text-[16px]">person_search</span>
                  <span>Browse Registered Users</span>
                </button>
              </div>
            ) : (
              filteredChats.map((chat) => {
                const otherUid = chat.participants.find((p) => p !== currentUser.uid) || '';
                const otherUser = chat.participantDetails?.[otherUid];
                const unread = chat.unreadCounts?.[currentUser.uid] || 0;
                const isSelected = chat.chatId === activeChatId;

                return (
                  <div
                    key={chat.chatId}
                    onClick={() => {
                      onSelectChat(chat);
                      onClose();
                    }}
                    className={`flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-primary-fixed/40 border border-primary/20'
                        : 'hover:bg-surface-container-low'
                    }`}
                  >
                    <div className="relative flex-shrink-0">
                      <img
                        src={
                          otherUser?.profilePhotoUrl ||
                          `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUid}`
                        }
                        alt={otherUser?.fullName || 'User'}
                        className="w-12 h-12 rounded-full object-cover shadow-xs"
                      />
                      {otherUser?.isOnline && (
                        <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-tertiary-fixed-dim ring-2 ring-surface"></span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-semibold text-sm text-on-surface truncate">
                          {otherUser?.fullName || 'User'}
                        </span>
                        <span className="text-[10px] text-on-surface-variant flex-shrink-0">
                          {chat.lastMessageTime
                            ? new Date(chat.lastMessageTime).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : ''}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs text-on-surface-variant truncate">
                          {chat.typingStatus?.[otherUid] ? (
                            <span className="text-primary font-medium italic">typing...</span>
                          ) : (
                            chat.lastMessage || 'Tap to chat'
                          )}
                        </p>
                        {unread > 0 && (
                          <span className="w-5 h-5 rounded-full bg-primary text-on-primary text-[10px] font-bold flex items-center justify-center flex-shrink-0">
                            {unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )
          )}

          {/* TAB 2: REGISTERED USERS & CONTACTS */}
          {activeTab === 'users' && (
            <div>
              <div className="p-2 mb-1 bg-surface-container-low rounded-xl">
                <span className="text-[11px] font-bold text-primary uppercase tracking-wider block">
                  Registered V-CHAT Users ({filteredUsers.length})
                </span>
                <span className="text-[10px] text-on-surface-variant">
                  Click on any user or tap "Start Chat" to message them in real time.
                </span>
              </div>

              {filteredUsers.length === 0 ? (
                <div className="text-center py-10 px-4 text-on-surface-variant">
                  <span className="material-symbols-outlined text-[40px] text-outline mb-2">person_off</span>
                  <p className="text-sm font-semibold">No other registered users found</p>
                  <p className="text-xs mt-1 text-outline">
                    {searchQuery ? 'No users matched your search.' : 'Open another tab or phone and register User B to see them appear here instantly!'}
                  </p>
                </div>
              ) : (
                <div className="space-y-1.5 pt-1">
                  {filteredUsers.map((user) => (
                    <div
                      key={user.uid}
                      onClick={() => {
                        onStartChatWithUser(user);
                        onClose();
                      }}
                      className="flex items-center gap-3 p-3 rounded-2xl bg-surface-container-lowest hover:bg-surface-container transition-all border border-surface-container shadow-xs cursor-pointer group"
                    >
                      <div className="relative flex-shrink-0">
                        <img
                          src={
                            user.profilePhotoUrl ||
                            `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username || user.uid}`
                          }
                          alt={user.fullName}
                          className="w-11 h-11 rounded-full object-cover shadow-xs"
                        />
                        {user.isOnline && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-tertiary-fixed-dim ring-2 ring-surface"></span>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-semibold text-xs text-on-surface truncate">
                            {user.fullName || user.username}
                          </span>
                          {user.isVerified && (
                            <span
                              className="material-symbols-outlined text-[13px] text-primary"
                              style={{ fontVariationSettings: "'FILL' 1" }}
                            >
                              verified
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] font-semibold text-primary block truncate">
                          @{user.username}
                        </span>
                        {user.bio && (
                          <span className="text-[10px] text-on-surface-variant block truncate">
                            {user.bio}
                          </span>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onStartChatWithUser(user);
                          onClose();
                        }}
                        className="py-1 px-3 rounded-full bg-primary/10 hover:bg-primary text-primary hover:text-white text-xs font-semibold flex items-center gap-1 transition-all flex-shrink-0 shadow-xs active:scale-95"
                      >
                        <span className="material-symbols-outlined text-[15px]">chat</span>
                        <span>Start Chat</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: GROUPS */}
          {activeTab === 'groups' && (
            <div>
              <div className="p-2">
                <button
                  type="button"
                  onClick={onNewGroupClick}
                  className="w-full py-2.5 px-3 bg-secondary/10 hover:bg-secondary/20 text-secondary rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors mb-2"
                >
                  <span className="material-symbols-outlined text-[18px]">group_add</span>
                  <span>Create New Group</span>
                </button>
              </div>

              {filteredGroups.length === 0 ? (
                <div className="text-center py-10 px-4 text-on-surface-variant">
                  <span className="material-symbols-outlined text-[40px] text-outline mb-2">group</span>
                  <p className="text-sm font-semibold">No groups yet</p>
                  <p className="text-xs mt-1 text-outline">Create a group to chat with multiple friends simultaneously!</p>
                </div>
              ) : (
                filteredGroups.map((group) => (
                  <div
                    key={group.groupId}
                    onClick={() => {
                      onSelectGroup(group);
                      onClose();
                    }}
                    className="flex items-center gap-3 p-3 rounded-2xl hover:bg-surface-container-low cursor-pointer transition-colors"
                  >
                    <img
                      src={group.groupPhoto || `https://api.dicebear.com/7.x/identicon/svg?seed=${group.groupId}`}
                      alt={group.groupName}
                      className="w-12 h-12 rounded-full object-cover shadow-xs"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-semibold text-sm text-on-surface truncate">
                          {group.groupName}
                        </span>
                        <span className="text-[10px] text-on-surface-variant flex-shrink-0">
                          {group.lastMessageTime
                            ? new Date(group.lastMessageTime).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : ''}
                        </span>
                      </div>
                      <p className="text-xs text-on-surface-variant truncate">
                        {group.lastMessage || 'No messages yet'}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
