import React, { useState } from 'react';
import { VChatUser } from '../types';
import { updateUserProfile } from '../firebase/authService';
import { uploadMediaFile, compressImage } from '../firebase/storageService';

interface ProfileModalProps {
  isOpen: boolean;
  currentUser: VChatUser;
  onClose: () => void;
  onUpdate: (updated: VChatUser) => void;
  onDeleteAccount?: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  currentUser,
  onClose,
  onUpdate,
  onDeleteAccount,
}) => {
  const [fullName, setFullName] = useState(currentUser.fullName);
  const [bio, setBio] = useState(currentUser.bio || '');
  const [about, setAbout] = useState(currentUser.about || '');
  const [profilePhotoUrl, setProfilePhotoUrl] = useState(currentUser.profilePhotoUrl || '');
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setStatusMsg('Compressing & uploading photo...');
    try {
      const compressed = await compressImage(file, 600, 600, 0.85);
      const url = await uploadMediaFile(compressed, `users/${currentUser.uid}/profile/avatar_${Date.now()}.jpg`);
      setProfilePhotoUrl(url);
      setStatusMsg('Photo uploaded!');
      setTimeout(() => setStatusMsg(null), 2000);
    } catch {
      setStatusMsg('Failed to upload photo.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setStatusMsg(null);
    try {
      const updates = {
        fullName: fullName.trim(),
        bio: bio.trim(),
        about: about.trim(),
        profilePhotoUrl,
      };
      await updateUserProfile(currentUser.uid, updates);
      onUpdate({ ...currentUser, ...updates });
      setStatusMsg('Profile updated successfully!');
      setTimeout(() => {
        setStatusMsg(null);
        onClose();
      }, 1000);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Failed to save');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-surface-container-lowest max-w-md w-full rounded-3xl shadow-2xl p-6 border border-surface-container-high animate-scaleUp max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg text-on-surface">My Profile</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {statusMsg && (
          <div className="mb-3 p-2.5 rounded-xl bg-primary/10 text-primary text-xs flex items-center gap-2">
            <span className="material-symbols-outlined text-[16px]">info</span>
            <span>{statusMsg}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="flex flex-col gap-3.5">
          {/* Avatar center */}
          <div className="flex flex-col items-center gap-2 py-2">
            <div className="relative group">
              <img
                src={
                  profilePhotoUrl ||
                  'https://lh3.googleusercontent.com/aida-public/AB6AXuBccHs75S8w_0EcCl3YJUkaqtGmJGR7L0bycQEc8jxmA2C1nbpcc7lFIYdoy0Gvqwdbdqy6GhozvuSZcOTvva_QxvevGBVcM0wWDrrXSiollcRqtl9PaZWldC_KnE1B0vFzYmVfJhiof-09T8qiarTgbmgv5QF1FltkRnlTJoWUKAuSgNVP4ASt-VwplL__iIaShArOFTHKfdjq6LSQ_6Xk-KTOcFmPWXYaA932vvSf'
                }
                alt={fullName}
                className="w-24 h-24 rounded-full object-cover shadow-md ring-4 ring-primary/20"
              />
              <label className="absolute inset-0 bg-black/40 rounded-full flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                <span className="material-symbols-outlined text-[24px]">photo_camera</span>
                <span className="text-[10px] font-semibold mt-0.5">Change</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  disabled={isUploading}
                  className="hidden"
                />
              </label>
            </div>
            {isUploading && (
              <span className="text-xs text-primary font-medium">Uploading new photo...</span>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Full Name</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Username</label>
            <input
              type="text"
              disabled
              value={`@${currentUser.username}`}
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-low text-xs text-outline cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Email</label>
            <input
              type="text"
              disabled
              value={currentUser.email}
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-low text-xs text-outline cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Status / Bio</label>
            <input
              type="text"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="e.g. Product Lead • Online"
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">About</label>
            <textarea
              rows={2}
              value={about}
              onChange={(e) => setAbout(e.target.value)}
              placeholder="Write a little about yourself..."
              className="w-full px-3.5 py-2 rounded-xl border border-surface-container-high bg-surface-container-lowest text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={isSaving || isUploading}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-primary-container to-secondary text-white font-semibold text-xs shadow-md mt-1 flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
          >
            {isSaving ? 'Saving Changes...' : 'Save Changes'}
          </button>
        </form>

        {/* Delete account */}
        <div className="mt-6 pt-4 border-t border-surface-container">
          {!showDeleteConfirm ? (
            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="text-xs text-error font-semibold hover:underline flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">delete_forever</span>
              <span>Delete My Account</span>
            </button>
          ) : (
            <div className="p-3 bg-error-container/20 rounded-xl border border-error/20 flex flex-col gap-2">
              <span className="text-xs text-error font-semibold">
                Are you sure? This will remove your profile and personal data.
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-1 bg-surface-container rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={onDeleteAccount}
                  className="px-3 py-1 bg-error text-white rounded-lg text-xs font-semibold"
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
