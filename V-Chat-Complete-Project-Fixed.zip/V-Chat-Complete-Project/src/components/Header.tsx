import React, { useState } from 'react';
import { VChatUser } from '../types';
import { downloadProjectZipLocally } from '../utils/zipExporter';

interface HeaderProps {
  currentUser: VChatUser | null;
  onOpenProfile: () => void;
  onOpenConversations: () => void;
  onOpenNewChat: () => void;
  onOpenNewGroup: () => void;
  onOpenPrivacy: () => void;
  onLogout: () => void;
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  onSwitchUser?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onOpenProfile,
  onOpenConversations,
  onOpenNewChat,
  onOpenNewGroup,
  onOpenPrivacy,
  onLogout,
  title = 'Direct Chat View',
  showBack = false,
  onBack,
  onSwitchUser,
}) => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      await downloadProjectZipLocally();
    } catch (err) {
      console.error('ZIP export error:', err);
      // Fallback to static asset if memory generator fails
      window.open('/V-Chat-Complete-Project.zip', '_blank');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <header className="fixed top-0 w-full z-40 pt-safe bg-surface/85 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.03)] border-b border-surface-container">
      <div className="max-w-4xl mx-auto h-16 px-4 flex items-center justify-between gap-3">
        {/* Left: Back/Menu + Logo + Title */}
        <div className="flex items-center gap-1.5 min-w-0">
          {showBack ? (
            <button
              onClick={onBack}
              aria-label="Back to conversations"
              className="w-10 h-10 -ml-1 flex items-center justify-center rounded-full text-on-surface hover:bg-surface-container-high transition-colors"
            >
              <span className="material-symbols-outlined text-[24px]">arrow_back</span>
            </button>
          ) : (
            <button
              onClick={onOpenConversations}
              aria-label="Open chats"
              className="w-10 h-10 -ml-1 flex items-center justify-center rounded-full text-on-surface hover:bg-surface-container-high transition-colors"
            >
              <span className="material-symbols-outlined text-[24px]">menu</span>
            </button>
          )}

          <img
            alt="V-CHAT App Logo"
            className="h-7 w-auto object-contain flex-shrink-0 cursor-pointer"
            onClick={onOpenConversations}
            src="https://lh3.googleusercontent.com/aida/AEtjO1XJLq4eXvG5vN8KHZd8xZ6dRZi7A-D3ncF4PMw4GL-yv5GnaLw0xk6uezSqrnz-nawi-4oPD-vEVC53kVBNdUuW4qjOjqvHvki2VQn14h_6wWXGpVpTmgpRv9SNkDlxldU0MhgCfAPn1WdQG0PyPtyshJjzbPr76A6Dm9Cj1JBv9A0AkdO2EGz0nrzlDAu8VT_pzviQVGncf-aERFJefNVwV8uepY8vXqZIMt7ir5YYvw"
          />

          <h1 className="font-semibold text-lg text-on-surface truncate ml-1">{title}</h1>
        </div>

        {/* Right: Actions + Profile Menu */}
        <div className="flex items-center gap-1.5">
          {/* Direct In-Browser Download ZIP button (No cookie check!) */}
          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={isExporting}
            title="Download Complete Project ZIP"
            className="h-8 px-2.5 rounded-full bg-primary/10 hover:bg-primary text-primary hover:text-white flex items-center gap-1 text-xs font-bold transition-all shadow-xs active:scale-95 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">
              {isExporting ? 'hourglass_top' : 'download'}
            </span>
            <span className="text-[11px]">{isExporting ? 'Packaging...' : 'ZIP'}</span>
          </button>

          {/* Find registered users action */}
          <button
            onClick={onOpenNewChat}
            title="Registered Users & Contacts"
            className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface-variant hover:text-primary hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[22px]">person_search</span>
          </button>

          {/* Quick Chats list button */}
          <button
            onClick={onOpenConversations}
            title="All Conversations"
            className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface-variant hover:text-primary hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[22px]">chat</span>
          </button>

          {/* More options dropdown */}
          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Menu"
              className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface-variant hover:text-primary hover:bg-surface-container-high transition-colors"
            >
              <span className="material-symbols-outlined text-[22px]">more_vert</span>
            </button>

            {menuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setMenuOpen(false)}
                />
                <div className="absolute right-0 top-12 w-60 bg-surface-container-lowest rounded-2xl shadow-xl border border-surface-container-high py-2 z-50 text-sm">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenNewChat();
                    }}
                    className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-on-surface hover:bg-surface-container transition-colors"
                  >
                    <span className="material-symbols-outlined text-[20px] text-primary">person_add</span>
                    <span>Find Registered Users</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenNewGroup();
                    }}
                    className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-on-surface hover:bg-surface-container transition-colors"
                  >
                    <span className="material-symbols-outlined text-[20px] text-secondary">group_add</span>
                    <span>New Group</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenProfile();
                    }}
                    className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-on-surface hover:bg-surface-container transition-colors"
                  >
                    <span className="material-symbols-outlined text-[20px] text-on-surface-variant">account_circle</span>
                    <span>My Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenPrivacy();
                    }}
                    className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-on-surface hover:bg-surface-container transition-colors"
                  >
                    <span className="material-symbols-outlined text-[20px] text-on-surface-variant">security</span>
                    <span>Privacy & Settings</span>
                  </button>

                  {/* In-Browser Direct Download ZIP option (No cookie check!) */}
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      handleDownloadZip();
                    }}
                    className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-tertiary hover:bg-surface-container transition-colors font-medium border-t border-surface-container cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">download</span>
                    <span>Download Project ZIP</span>
                  </button>

                  {onSwitchUser && (
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onSwitchUser();
                      }}
                      className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-on-surface hover:bg-surface-container transition-colors"
                    >
                      <span className="material-symbols-outlined text-[20px] text-primary">swap_horiz</span>
                      <span>Switch / Log In Another User</span>
                    </button>
                  )}

                  <div className="h-px bg-surface-container my-1" />

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      onLogout();
                    }}
                    className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-error hover:bg-error-container/20 transition-colors"
                  >
                    <span className="material-symbols-outlined text-[20px]">logout</span>
                    <span>Sign Out</span>
                  </button>
                </div>
              </>
            )}
          </div>

          {/* User profile avatar thumbnail */}
          <div className="pl-1 flex items-center">
            <button
              onClick={onOpenProfile}
              title={currentUser?.fullName || 'Profile'}
              className="relative rounded-full focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              <img
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover ring-2 ring-primary/20"
                src={
                  currentUser?.profilePhotoUrl ||
                  'https://lh3.googleusercontent.com/aida-public/AB6AXuBccHs75S8w_0EcCl3YJUkaqtGmJGR7L0bycQEc8jxmA2C1nbpcc7lFIYdoy0Gvqwdbdqy6GhozvuSZcOTvva_QxvevGBVcM0wWDrrXSiollcRqtl9PaZWldC_KnE1B0vFzYmVfJhiof-09T8qiarTgbmgv5QF1FltkRnlTJoWUKAuSgNVP4ASt-VwplL__iIaShArOFTHKfdjq6LSQ_6Xk-KTOcFmPWXYaA932vvSf'
                }
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-tertiary-fixed-dim ring-1.5 ring-surface"></span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
