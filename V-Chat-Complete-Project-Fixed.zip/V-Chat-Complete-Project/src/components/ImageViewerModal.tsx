import React from 'react';

interface ImageViewerModalProps {
  isOpen: boolean;
  imageUrl: string | null;
  fileName?: string;
  onClose: () => void;
  onForward?: (url: string) => void;
}

export const ImageViewerModal: React.FC<ImageViewerModalProps> = ({
  isOpen,
  imageUrl,
  fileName,
  onClose,
  onForward,
}) => {
  if (!isOpen || !imageUrl) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = fileName || `vchat_image_${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between p-4 animate-fadeIn">
      {/* Top action bar */}
      <div className="flex items-center justify-between text-white z-10">
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
        >
          <span className="material-symbols-outlined text-[24px]">arrow_back</span>
        </button>

        <span className="font-semibold text-sm truncate max-w-[200px]">
          {fileName || 'Photo'}
        </span>

        <div className="flex items-center gap-2">
          {onForward && (
            <button
              onClick={() => onForward(imageUrl)}
              title="Forward Photo"
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <span className="material-symbols-outlined text-[20px]">forward</span>
            </button>
          )}

          <button
            onClick={handleDownload}
            title="Download Photo"
            className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">download</span>
          </button>
        </div>
      </div>

      {/* Image container */}
      <div className="flex-1 flex items-center justify-center p-2 overflow-hidden">
        <img
          src={imageUrl}
          alt={fileName || 'View'}
          className="max-h-full max-w-full object-contain rounded-xl shadow-2xl transition-transform"
        />
      </div>

      {/* Bottom spacer */}
      <div className="h-6" />
    </div>
  );
};
