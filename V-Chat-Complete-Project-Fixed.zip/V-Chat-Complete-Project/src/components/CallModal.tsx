import React, { useState, useEffect } from 'react';
import { VChatCall } from '../types';

interface CallModalProps {
  call: VChatCall | null;
  isIncoming: boolean;
  onAccept: () => void;
  onDecline: () => void;
  onEnd: (durationSeconds: number) => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  call,
  isIncoming,
  onAccept,
  onDecline,
  onEnd,
}) => {
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    if (call?.status === 'accepted') {
      setIsConnected(true);
    }
  }, [call?.status]);

  useEffect(() => {
    let timer: number | null = null;
    if (isConnected) {
      timer = window.setInterval(() => {
        setDuration((sec) => sec + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isConnected]);

  if (!call) return null;

  const targetName = isIncoming ? call.callerName : call.receiverName;
  const targetPhoto = isIncoming ? call.callerPhoto : call.receiverPhoto;

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainder = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-inverse-surface/95 backdrop-blur-xl flex flex-col justify-between p-6 text-inverse-on-surface animate-fadeIn">
      {/* Top Bar */}
      <div className="flex flex-col items-center gap-1 pt-6">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container/20 text-xs uppercase tracking-wider font-semibold">
          <span className="material-symbols-outlined text-[14px]">
            {call.callType === 'video' ? 'videocam' : 'call'}
          </span>
          <span>{call.callType === 'video' ? 'V-CHAT Video Call' : 'V-CHAT Voice Call'}</span>
        </span>
        <span className="text-xs text-inverse-on-surface/70 mt-1">
          {isConnected ? formatTimer(duration) : isIncoming ? 'Incoming Call...' : 'Calling...'}
        </span>
      </div>

      {/* Middle: Avatar & Pulsing Rings */}
      <div className="flex-1 flex flex-col items-center justify-center my-6">
        <div className="relative flex items-center justify-center">
          {!isConnected && (
            <>
              <div className="absolute w-44 h-44 rounded-full bg-primary/20 animate-ping" />
              <div className="absolute w-36 h-36 rounded-full bg-secondary/30 animate-pulse" />
            </>
          )}
          <img
            src={
              targetPhoto ||
              'https://lh3.googleusercontent.com/aida-public/AB6AXuDEEn0wOXHoTVZ8NVMgBbshd2PIpJD1bKFOmK2JfETKl07UJqY1Alaia1_MGjyEq-XXj6iyJrPU4M4f40u63w9Q_1DQPaB6xOzQXcdwxr_QNJ1ouDtHh7x4z_mUTilbXFeq7Lu4hTcCAQlGXgccjcKb1iqE10P28Jo8gQ7PIj3Gb4ErvCauVR38xMgc5mLJeoJV7UBcr4xmoU4yacVwNNAIr6tCJMf8pDVMCVDGog8b'
            }
            alt={targetName}
            className="w-28 h-28 rounded-full object-cover shadow-2xl ring-4 ring-primary/40 relative z-10"
          />
        </div>
        <h2 className="text-2xl font-bold mt-6 tracking-tight">{targetName}</h2>
        <p className="text-sm text-inverse-on-surface/70 mt-1">
          {isConnected ? 'Connected • End-to-End Encrypted' : 'Connecting to peer...'}
        </p>
      </div>

      {/* Bottom Controls */}
      <div className="flex flex-col items-center gap-6 max-w-sm mx-auto w-full pb-6">
        {isConnected ? (
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                isMuted ? 'bg-error text-white' : 'bg-surface-container/30 text-white hover:bg-surface-container/50'
              }`}
            >
              <span className="material-symbols-outlined text-[24px]">
                {isMuted ? 'mic_off' : 'mic'}
              </span>
            </button>

            {call.callType === 'video' && (
              <button
                onClick={() => setIsVideoOff(!isVideoOff)}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  isVideoOff ? 'bg-error text-white' : 'bg-surface-container/30 text-white hover:bg-surface-container/50'
                }`}
              >
                <span className="material-symbols-outlined text-[24px]">
                  {isVideoOff ? 'videocam_off' : 'videocam'}
                </span>
              </button>
            )}

            <button
              onClick={() => onEnd(duration)}
              className="w-16 h-16 rounded-full bg-error text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
            >
              <span className="material-symbols-outlined text-[28px]">call_end</span>
            </button>
          </div>
        ) : isIncoming ? (
          <div className="flex items-center justify-around w-full px-4">
            <button
              onClick={onDecline}
              className="flex flex-col items-center gap-1.5"
            >
              <div className="w-16 h-16 rounded-full bg-error text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform">
                <span className="material-symbols-outlined text-[28px]">call_end</span>
              </div>
              <span className="text-xs font-semibold">Decline</span>
            </button>

            <button
              onClick={onAccept}
              className="flex flex-col items-center gap-1.5"
            >
              <div className="w-16 h-16 rounded-full bg-tertiary-fixed-dim text-on-tertiary-fixed flex items-center justify-center shadow-lg active:scale-95 transition-transform">
                <span className="material-symbols-outlined text-[28px]">call</span>
              </div>
              <span className="text-xs font-semibold">Accept</span>
            </button>
          </div>
        ) : (
          <button
            onClick={() => onEnd(0)}
            className="w-16 h-16 rounded-full bg-error text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined text-[28px]">call_end</span>
          </button>
        )}
      </div>
    </div>
  );
};
