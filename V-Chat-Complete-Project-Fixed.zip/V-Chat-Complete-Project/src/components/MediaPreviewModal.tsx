import React, { useState } from 'react';

interface MediaFileItem {
  file: File;
  previewUrl: string;
  type: 'image' | 'video';
}

interface MediaPreviewModalProps {
  isOpen: boolean;
  mediaFiles: MediaFileItem[];
  onClose: () => void;
  onSend: (mediaFiles: MediaFileItem[], caption: string) => void;
  onRemoveItem: (index: number) => void;
  isUploading: boolean;
  uploadProgress: number;
}

export const MediaPreviewModal: React.FC<MediaPreviewModalProps> = ({
  isOpen,
  mediaFiles,
  onClose,
  onSend,
  onRemoveItem,
  isUploading,
  uploadProgress,
}) => {
  const [caption, setCaption] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  if (!isOpen || mediaFiles.length === 0) return null;

  const currentItem = mediaFiles[selectedIndex] || mediaFiles[0];

  const handleSend = () => {
    onSend(mediaFiles, caption);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col justify-between p-4 animate-fadeIn">
      {/* Top Bar */}
      <div className="flex items-center justify-between text-white z-10">
        <button
          type="button"
          onClick={onClose}
          disabled={isUploading}
          className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
        >
          <span className="material-symbols-outlined text-[24px]">close</span>
        </button>

        <span className="text-sm font-semibold">
          Preview Media ({selectedIndex + 1}/{mediaFiles.length})
        </span>

        <div className="w-10" />
      </div>

      {/* Main Preview */}
      <div className="flex-1 flex items-center justify-center p-2 relative overflow-hidden">
        {currentItem.type === 'video' ? (
          <video
            src={currentItem.previewUrl}
            controls
            className="max-h-[60vh] max-w-full rounded-2xl shadow-2xl object-contain bg-black"
          />
        ) : (
          <img
            src={currentItem.previewUrl}
            alt="Preview"
            className="max-h-[60vh] max-w-full rounded-2xl shadow-2xl object-contain"
          />
        )}
      </div>

      {/* Thumbnails strip if multiple */}
      {mediaFiles.length > 1 && (
        <div className="flex items-center justify-center gap-2 py-2 overflow-x-auto">
          {mediaFiles.map((item, idx) => (
            <div
              key={idx}
              className={`relative rounded-xl overflow-hidden cursor-pointer w-14 h-14 flex-shrink-0 border-2 transition-all ${
                selectedIndex === idx ? 'border-primary ring-2 ring-primary/40' : 'border-white/30 opacity-60'
              }`}
              onClick={() => setSelectedIndex(idx)}
            >
              {item.type === 'video' ? (
                <div className="w-full h-full bg-black/60 flex items-center justify-center text-white">
                  <span className="material-symbols-outlined text-[20px]">videocam</span>
                </div>
              ) : (
                <img src={item.previewUrl} alt="" className="w-full h-full object-cover" />
              )}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onRemoveItem(idx);
                }}
                className="absolute top-0.5 right-0.5 w-4 h-4 bg-black/80 rounded-full text-white flex items-center justify-center"
              >
                <span className="material-symbols-outlined text-[10px]">close</span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Upload Progress feedback */}
      {isUploading && (
        <div className="max-w-md mx-auto w-full mb-3 bg-white/10 rounded-2xl p-3 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-white mb-1.5 font-semibold">
            <span>Uploading to Firebase Storage...</span>
            <span>{uploadProgress}%</span>
          </div>
          <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
            <div
              className="bg-primary-container h-full transition-all duration-200"
              style={{ width: `${Math.max(uploadProgress, 10)}%` }}
            />
          </div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className="max-w-md mx-auto w-full flex flex-col gap-2 z-10">
        <input
          type="text"
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          disabled={isUploading}
          placeholder="Add a caption..."
          className="w-full bg-white/20 text-white placeholder-white/60 px-4 py-3 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary backdrop-blur-md border border-white/20"
        />

        <div className="flex items-center gap-3 mt-1">
          <button
            type="button"
            onClick={onClose}
            disabled={isUploading}
            className="py-3 px-6 bg-white/20 hover:bg-white/30 text-white rounded-full font-semibold text-sm transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleSend}
            disabled={isUploading}
            className="flex-1 py-3 bg-gradient-to-r from-primary-container to-secondary text-white rounded-full font-semibold text-sm shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
          >
            {isUploading ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Sending ({uploadProgress}%)...</span>
              </>
            ) : (
              <>
                <span>Send Media</span>
                <span className="material-symbols-outlined text-[18px]">send</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
