# V-Chat project repair notes

This package contains the original V-Chat source project with targeted fixes.

## What was corrected
1. Text send now awaits Firebase completion and preserves the draft when it fails.
2. If no chat is selected, the app opens the registered-users directory instead of using stale state.
3. Login no longer auto-starts a chat with the first listed user.
4. Direct-chat creation errors are no longer swallowed.
5. A separate `publicUsers` collection is used for the public username directory; private email/phone details remain in `users`.
6. Media upload errors are no longer converted to local Data URLs that another device cannot retrieve.
7. Firestore/Storage rules were tightened to participant-based chat access.

## Before testing
- Confirm the Firebase project in `firebase-applet-config.json` is yours.
- Create the Firestore database ID specified there (`vchat-db`) or change it to `(default)` if that is the database you created.
- Enable Email/Password (and Google if used) in Firebase Authentication.
- Enable Cloud Firestore and Firebase Storage.
- Deploy `firestore.rules` and `storage.rules`.
- Existing users should log in once so their `publicUsers` profile is synchronized.
- Test with two separate accounts/devices.

## Verification limitation
The ZIP archive itself passed integrity checking. This environment could not complete `npm install` within the available time, and it has no access to the user's Firebase console, so a successful production build or live two-device Firebase test is not claimed.
